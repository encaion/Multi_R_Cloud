
elec = read.csv("elec_load.csv")
head(elec, 2)

# Q. elec객체를 연도별로 나누어 각각의 파일에 저장하시오.
# ※ 파일명은 elec_load_year_2008.csv 형식으로 한다.
# ※ 작업폴더 아래에 elec 폴더를 만들어 각 파일을 저장한다.
# ※ 년도 변수는 제외하고 저장한다.
dir.create("elec")
# list.files()

head(elec, 2)
tail(elec, 2)
table(elec$YEAR)
for(year in unique(elec$YEAR)){
  elec_sub = elec[elec$YEAR == year, -1]
  write.csv(elec_sub, paste0("elec/elec_load_year_", year, ".csv"),
            row.names = FALSE)
}

data(package = "ggplot2") # ggplot2 패키지의 데이터 세트 목록


df = read.csv("corr_national_indices.csv")
head(df)
df[1:5, "S.P500"]
is.na(df[1:5, "S.P500"])

df_sample = df[1:5, "S.P500"]
df_sample[is.na(df_sample) == FALSE]

# Q1. S.P500 변수가 결측이 아닌 row만 추출하여
#     df_not_na 객체에 저장하시오.
df_not_na = df[is.na(df$S.P500) == FALSE, ]
head(df_not_na)
summary(df_not_na)

# Q2. JPX400 변수의 결측치 개수를 출력하시오.
# (단, is.na() 함수와 sum() 함수를 활용)
nrow(df[is.na(df$JPX400), ])
is.na(df$JPX400)[1:6]
sum(is.na(df$JPX400))

# Q3. 1차원 벡터의 결측치를 확인하는 사용자 정의 함수
#     check_na 를 만드시오.
# 예시) 입력: c(NA, NA, 2, 3), 출력: 2

check_na = function(x){
  sum(is.na(x))
}
check_na(c(NA, NA, 2, 3))

# Q4. df 객체의 각 변수별 결측치 개수를 출력해보시오.
#     apply() 함수 활용 권장. check_na() 함수 활용 권장.

sum(c(2, 4, 6))
apply(df, 1, FUN = "sum")
apply(X = df, MARGIN = 2, FUN = "check_na")
apply(X = df, MARGIN = 2, FUN = function(x){sum(is.na(x))})
# 일회성 함수. 람다(lambda) 함수

vec_na = c()
for(n in 1:ncol(df)){
  vec_na = c(vec_na, sum(is.na(df[, n])))
}
names(vec_na) = colnames(df)
vec_na

head(df)
mean(df$SSEC)
mean(df$SSEC, na.rm = TRUE) # rm -> remove
df[is.na(df$SSEC), "SSEC"] = mean(df$SSEC, na.rm = TRUE)
head(df)



bike = read.csv("bike.csv")
head(bike, 2)

library("lubridate")
bike[, "wday" ] = wday(bike$datetime)
bike[, "wday2"] = wday(bike$datetime, week_start = 1) # 월요일 1
bike[, "wday3"] = wday(bike$datetime, label = TRUE)
bike[, "wday4"] = wday(bike$datetime, label = TRUE, week_start = 1)
head(bike, 2)

class(bike$wday3)
bike[1:2, "wday3"]
bike[1:2, "wday4"]

bike[, "wend"] = ifelse(test = bike$wday %in% c(1, 7),
                        yes = 1, no = 0)
bike[, "wend"] = ifelse(test = bike$wday2 >= 6,
                        yes = 1, no = 0)
bike[, "wend"] = (bike$wday2 >= 6) + 0
bike[, "wend"] = (bike$wday2 >= 6) * 1
c(TRUE, FALSE, FALSE) + 0
c(TRUE, FALSE, FALSE) * 1

# Q1. 주중과 주말의 casual 평균을 계산하여
#     df_casual에 저장하시오.
df_casual = aggregate(data = bike, casual ~ wend, FUN = "mean")

# Q2. 주중과 주말의 registered 평균을 계산하여
#     df_registered에 저장하시오.
df_registered = aggregate(data = bike, 
                          registered ~ wend, FUN = "mean")

# Q3. df_casual과 df_registered의 결과를 병합하시오.
#     (단, join 연산을 실시하여 병합하시오.)
library("dplyr")
df_join = left_join(x = df_casual, y = df_registered,
                    by = c("wend" = "wend"))
df_join = left_join(x = df_casual, y = df_registered,
                    by = "wend")
df_join = left_join(x = df_casual, y = df_registered)

df_join = inner_join(x = df_casual, y = df_registered,
                     by = c("wend" = "wend"))
df_join = inner_join(x = df_casual, y = df_registered,
                     by = "wend")
df_join = inner_join(x = df_casual, y = df_registered)

# install.packages("reshape2")
library("reshape2")
set.seed(2)
sample(x = 1:45, size = 6)

set.seed(123)
df = data.frame(Obs = 1:4,
                A = sample(10:99, size = 4),
                B = sample(10:99, size = 4),
                C = sample(10:99, size = 4))
df

df_melt = melt(data = df, id.vars = "Obs",
               variable.name = "Group", value.name = "Count")
df_melt

elec = read.csv("elec_load.csv")
head(elec, 2)

elec_melt = melt(data = elec, id.vars = c("YEAR", "MONTH", "DAY"))
head(elec_melt)
# Q1. 4, 5 번째 변수명을 각각 HOUR, LOAD로 변경하시오.
colnames(elec_melt)[4:5] = c("HOUR", "LOAD")
head(elec_melt)

# write.csv(elec_melt, "elec_load_melt.csv", row.names = FALSE)

# Q2. 연도별 월별 전력부하량 평균을 계산하여,
#     elec_cast 객체에 저장하시오.
# (단, dcast() 함수 사용, fun.aggregate <--)
?dcast

elec_cast = dcast(data = elec_melt, value.var = "LOAD",
                  YEAR ~ MONTH, fun.aggregate = mean)
elec_cast

elec_agg = aggregate(data = elec_melt, LOAD ~ YEAR + MONTH, FUN = "mean")
head(elec_agg)

colnames(elec)
t(t(colnames(elec)))


library("ggplot2")
a <- ggplot(economics, aes(date, unemploy))
a + geom_path(lineend="butt", linejoin="round", linemitre=1)


data_point = data.frame(xx = 1:10,
                        yy = sample(1:10, 10))
data_point

ggplot() + geom_point(data_point,
                      aes(xx, yy))
ggplot() + geom_point(aes(xx, yy),
                      data_point)
ggplot() + geom_point(mapping = aes(xx, yy),
                      data = data_point)

ggplot(data = data_point,
       aes(x = xx, y = yy)) + 
  geom_point()

ggplot(data = data_point,
       aes(x = xx, y = yy)) + 
  geom_line()

ggplot(data = data_point,
       aes(x = xx, y = yy)) + 
  geom_col() # column, 막대그래프

ggplot(data = data_point,
       aes(x = xx, y = yy)) + 
  geom_bar(stat = "identity")

ggplot(data = data_point,
       aes(x = xx, y = yy)) + 
  geom_point(color = "#FFA500",
             size = 8,
             shape = "헐")


ggplot(data = data_point,
       aes(x = xx, y = yy)) + 
  geom_point()

ggplot(data = data_point,
       aes(x = xx, y = yy)) + 
  geom_point(size = 7)

ggplot(data = data_point,
       aes(x = xx, y = yy)) + 
  geom_point(size = 7) + 
  geom_line()

ggplot(data = data_point,
       aes(x = xx, y = yy)) + 
  geom_point(size = 7) + 
  geom_line(size = 1.4)

ggplot(data = data_point,
       aes(x = xx, y = yy)) + 
  geom_point(size = 7) + 
  geom_line(size = 1.4) + 
  theme_bw() # black & white theme

ggplot(data = data_point,
       aes(x = xx, y = yy)) + 
  geom_point(size = 7) + 
  geom_line(size = 1.4) + 
  geom_point(size = 5, color = "#FFFFFF") + 
  theme_bw()

ggplot(data = data_point,
       aes(x = xx, y = yy)) + 
  geom_point(size = 7) + 
  geom_line(size = 1.4) + 
  geom_point(size = 5, color = "#FFFFFF") + 
  geom_text(aes(label = LETTERS[1:10])) +
  theme_bw()

ggplot(data = data_point,
       aes(x = xx, y = yy)) + 
  geom_point(size = 7) + 
  geom_line(size = 1.4) + 
  geom_point(size = 5, color = "#FFFFFF") + 
  geom_text(aes(label = LETTERS[1:10])) +
  geom_hline(yintercept = 8, color = "#FF0000") +
  theme_bw()

ggplot(data = data_point,
       aes(x = xx, y = yy)) + 
  geom_hline(yintercept = 8, color = "#FF0000") +
  geom_point(size = 7) + 
  geom_line(size = 1.4) + 
  geom_point(size = 5, color = "#FFFFFF") + 
  geom_text(aes(label = LETTERS[1:10])) +
  theme_bw()

?diamonds

df = as.data.frame(diamonds)
head(df, 2)
sapply(df, FUN = "class")
df[1:2, "cut"]

aggregate(data = df, price ~ cut, FUN = "min")
aggregate(data = df, price ~ cut, FUN = "max")
aggregate(data = df, price ~ cut, FUN = "quantile")

data_point
ggplot(data = data_point,
       aes(x = xx, y = yy)) + 
  geom_point(size = 3) + 
  geom_text(aes(y = yy + 0.5,
                label = yy))
