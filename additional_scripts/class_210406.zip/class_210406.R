# 도움말: ? 뒤에 함수명, help() 함수

?getwd
help("head")

# install.packages("imager")
library("imager")
img = load.image("sample_cat_image.jpg")
dim(img)
img[1:3, 1:3, 1, 1]
plot(img)

img[,,, 1] = 1 - img[,,, 1]
plot(img)

img[,,, 2] = 1 - img[,,, 2]
img[,,, 3] = 1 - img[,,, 3]
plot(img)
