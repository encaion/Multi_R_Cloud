getwd()

#### 1. 시작하기 ####
#### ___ 1) 기본 문법 ####

1 + 1

install.packages("beepr")
library("beepr")
beep(2)
beepr::beep(2)

install.packages("data.table")

library("data.table")
as.numeric("a")
"a" + 1

aaa = function(x){}
aaa()

bbb = function(){
  print("Rloha")
}
bbb()
getwd()

ccc = function(x){
  print(x)
}
ccc()
ccc(123124)
ccc(x = 123124)
ccc(y = 123124)

ddd = function(x){
  x + 3
}
ddd(2)

eee = function(x = 4){
  x * 5
}
eee()
eee(12312)

fff = function(aa, bb){
  aa * bb
}
fff(123)
fff(123, 436)
fff(aa = 123, bb = 436)

hhh = function(x){
  result = x * 2
  return(result) # 출력값 명시
}

TRUE
FALSE
TRUE + FALSE
FALSE + FALSE
sum(c(TRUE, FALSE, TRUE))

c(1, 2, 3)
c(1, 2, "a")
aa = c(4, 5, 6)
aa[2]
aa[c(1, 3)]
aa[3] = "kk"
aa

matrix(c(1, 2, 3, 4, 5, 6))
matrix(1:6)
matrix(1:6, nrow = 2)
matrix(1:6, ncol = 2)
matrix(1:6, ncol = 2, byrow = TRUE)

data.frame(aa = 1:3,
           bb = c("a", "b", "c"))
data.frame(aa = 1:4,
           bb = c("a", "b", "c"))
df = data.frame(aa = 1:3,
                bb = c("a", "b", "c"))
df
df$aa
df[, "aa"]

listt = list(aa = 1:3,
             bb = matrix(1:4, nrow = 2),
             cc = list(kk = 3:5,
                       jj = c("a", "c")))
listt
listt$aa[1]
listt$cc$kk[2]
listt$bb[, 2]

list.files()

install.packages("imager")
library("imager")
img = load.image("sample_cat_image.jpg")
plot(img)
dim(img)
img[1:3, 1:3, 1, 1]

img[,,, 1] = 1 - img[,,, 1]
plot(img)

img[,,, 2] = 1 - img[,,, 2]
img[,,, 3] = 1 - img[,,, 3]
plot(img)

text = readLines("https://www.naver.com",
                 encoding = "UTF-8")
text[2]

as.numeric("aa")
as.numeric("1234")
as.numeric("1,234")
as.numeric("1,234원")
as.numeric("1,234.56원")
as.numeric(gsub(pattern = "[^0-9.]", # 숫자 및 마침표 제외
                replacement = "",
                x = "1,234.56원"))

factor(c("a", "b", "c"))
factor(c("a", "b", "c"), labels = c("ㅎㅎ", "ㅋㅋ", "ㅈㅅ!"))

fac = factor(c(13, 22, 88), levels = c(88, 22, 13))
fac

as.numeric(fac)
as.numeric(as.character(fac))
fac[1] = 11

factor(c(13, 22, 88), levels = c(88, 22, 13),
       ordered = TRUE)

4:1
3:-4

seq(1, 3)
seq(from = 1, to = 3)
seq(1, 3, 1)
seq(from = 1, to = 3, by = 1)

seq(from = 1, to = 3, length.out = 8)
seq(from = 1, to = 3, length.out = 9)
?seq
?rep

rep(1:3, 3)
rep(3, 1:3)
rep(x = 1:3, times = 3)
rep(times = 3, x = 1:3)

rep(x = 1:3, each = 3)

aws = read.csv("AWS_sample.txt", sep = "#")
head(aws)

aa = 12342134
ls()

head(aws)
aws[, 2]
aws[2, ]


aws[1:3, ]
aws[1:3, -5] # 같음
aws[1:3, 1:4] # 같음

# for( 반복 규칙 ){
#   반복시 실행되는 코드
# }
for(n in 1:3){
  print(n)
}

df_1 = data.frame(aa = letters[1:4],
                  bb = 1:4)
for(num in 1:4){
  df_1[num, "new_column"] = num * 2
}

df_1 = data.frame(aa = letters[1:4],
                  bb = 1:4)
for(num in 1:4){
  Sys.sleep(3)
  df_1[num, "new_column"] = num * 2
  print(df_1)
}
df_1[, "new_column"] = (1:4) * 2
df_1
