set.seed(999)
n = 1000
df = data.frame(factors = sample(letters[1:8], n, replace = TRUE),
                x = rnorm(n), 
                y = runif(n))
head(df, 2)

col = rep(c("#FF0000", "#00FF00"), 4)

library("circlize")
# circos.clear()
circos.par("track.height" = 0.2)
circos.initialize(factors = df$factors, 
                  x = df$x)

circos.track(factors = df$factors,
             y = df$y,
             panel.fun = function(x, y){
               circos.text(CELL_META$xcenter, 
                           CELL_META$cell.ylim[2] - uy(2, "mm"), 
                           CELL_META$sector.index)
               circos.axis(labels.cex = 0.6)
             })

circos.trackPoints(df$factors, 
                   df$x, 
                   df$y, 
                   col = col, 
                   pch = 16, cex = 0.1)

par(new = TRUE)


circos.track(factors = df$factors,
             y = df$y,
             panel.fun = function(x, y){
               circos.text(CELL_META$xcenter, 
                           CELL_META$cell.ylim[2] - uy(2, "mm"), 
                           CELL_META$sector.index)
               circos.axis(labels.cex = 0.6)
             })

circos.trackPoints(df$factors, 
                   df$x, 
                   df$y, 
                   col = col, 
                   pch = 16, cex = 0.1)


df_sub = df[df$factors %in% c("a", "b"), ]
circos.track(factors = df_sub$factors,
             y = df_sub$y,
             panel.fun = function(x, y){
               circos.text(CELL_META$xcenter, 
                           CELL_META$cell.ylim[2] - uy(2, "mm"), 
                           CELL_META$sector.index)
               circos.axis(labels.cex = 0.6)
             })
circos.trackPoints(df_sub$factors, 
                   df_sub$x, 
                   df_sub$y, 
                   col = col, 
                   pch = 16, cex = 2)

df_sub2 = df[df$factors %in% c("a", "b"), ]
df_sub2[, "factors"] = as.character(df_sub2$factors)
circos.track(factors = df_sub$factors,
             y = df_sub$y,
             panel.fun = function(x, y){
               circos.text(CELL_META$xcenter, 
                           CELL_META$cell.ylim[2] - uy(2, "mm"), 
                           CELL_META$sector.index)
               circos.axis(labels.cex = 0.6)
             })

circos.trackPoints(df_sub$factors, 
                   df_sub$x, 
                   df_sub$y, 
                   col = col, 
                   pch = 16, cex = 2)


circos.text(x = -1, 
            y = 0.5, 
            labels = "text", 
            sector.index = "a",
            track.index = 2)
