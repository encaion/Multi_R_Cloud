# 실습 데이터 만들기
text1 = "1234 asdfASDF  ㄱㄴㄷㄹㅏㅑㅓㅕ가나다라   .!@#"
text2 = "<a> <ab> <abc> <abcd>"
text3 = c("aaa", "bbb", "ccc", "abc")

# 활용 함수
# ▶ gsub(): 패턴 치환
# ▶ grep(): 매칭되는 패턴을 포함하는 데이터 또는 그 위치를 출력
# ▶ grepl(): 패턴 매칭 결과를 논리값(TRUE/FALSE)으로 반환
# ▶ gregexpr(): 주어진 데이터에서 패턴이 매칭되는 결과를 리스트 형식으로 출력
# ▶ regmatches(): 패턴 매칭

# 숫자 치환
gsub(pattern = "[0-9]", replacement = "@", x = text1)

# 영문 치환
# __ 소문자 치환
gsub(pattern = "[a-z]", replacement = "@", x = text1)

# __ 대문자 치환
gsub(pattern = "[A-Z]", replacement = "@", x = text1)

# 한글 치환
# __ 자음 치환
gsub(pattern = "[ㄱ-ㅎ]", replacement = "@", x = text1)

# __ 모음 치환
gsub(pattern = "[ㅏ-ㅣ]", replacement = "@", x = text1)

# __ 완성형 치환
gsub(pattern = "[가-힣]", replacement = "@", x = text1)


# 띄어쓰기 치환
gsub(pattern = " ", replacement = "@", x = text1)
gsub(pattern = "  ", replacement = "@", x = text1)
gsub(pattern = "   ", replacement = "@", x = text1)

gsub(pattern = "  |   ", replacement = "@", x = text1)

# 두 칸 이상의 띄어쓰기를 모두 한 칸으로 치환
gsub(pattern = " {2,}", replacement = " ", x = text1)

gsub(pattern = " {2,3}", replacement = "@", x = text1)

# 응용
# __ 숫자가 아닌 모든 문자 치환
gsub(pattern = "[^0-9]", replacement = "@", x = text1)

# __ 영문자가 아닌 모든 문자 치환
gsub(pattern = "[^A-Z]|[^a-z]", replacement = "@", x = text1)
gsub(pattern = "[^A-z]", replacement = "@", x = text1)

gsub(pattern = "[^A-z]", replacement = "@",
     x = "abc ABC .(){}[]=+-_")

gsub(pattern = "[^A-Za-z]", replacement = "@",
     x = "abc ABC .(){}[]=+-_")

# __ 한글이 아닌 모든 문자 치환
gsub(pattern = "[^ㄱ-ㅎㅏ-ㅣ가-힣]", replacement = "@", 
     x = text1)

gsub(pattern = "[^ㄱ-힣]", replacement = "@", x = text1)

# __ 숫자와 영문 대문자가 아닌 모든 문자 치환
gsub(pattern = "[^0-9A-Z]", replacement = "@", x = text1)

# __ 숫자 2, 3만 치환
gsub(pattern = "2|3", replacement = "@", x = text1)
gsub(pattern = "[2-3]", replacement = "@", x = text1)
gsub(pattern = "[23]", replacement = "@", 
     x = "1234 12 23 213")

# __ 숫자 2, 3, 4, 7, 8, 9 치환
gsub(pattern = "[2-47-9]", replacement = "@", x = text1)

# __ '.'의 치환
gsub(pattern = ".", replacement = "@", x = text1)
gsub(pattern = "\\.", replacement = "@", x = text1)
gsub(pattern = "[.]", replacement = "@", x = text1)

# __ 두 칸 띄어쓰기와 세 칸 띄어쓰기의 치환
gsub(pattern = " {2,3}", replacement = "@", x = text1)

# __ "asdf"와 "가나다라" 치환
gsub(pattern = "asdf|가나다라", replacement = "@", x = text1)
gsub(pattern = "asdf|[가-라]", replacement = "@", x = text1)

# __ 1, 3 치환
gsub(pattern = "1|3", replacement = "@", x = text1)

# __ 1~3, 7~9 치환
gsub(pattern = "[1-37-9]", replacement = "@", x = text1)

# 특수문자내 문자 처리
# __ 모든 경우의 수 치환
gsub(pattern = "<.*?>", replacement = "@", x = text2)
# .*? : 0개 이상의 모든 문자열

# __ 내부 문자 1개 치환
gsub(pattern = "<.>", replacement = "@", x = text2)

# __ 내부 문자 2~4개 치환
gsub(pattern = "<.{2,4}>", replacement = "@", x = text2)

gsub(pattern = "<[a-z]{2,4}>", replacement = "@", x = text2)


# 텍스트 조건
# __ "a"를 포함하는 원소 추출
grep(pattern = "a", x = text3)
grep(pattern = "a", x = text3, value = TRUE)

# __ "b"를 포함하는 원소 추출
grep(pattern = "b", x = text3, value = TRUE)

# __ "b"로 시작하는 원소 추출
grep(pattern = "^b", x = text3, value = TRUE)

# __ "a"로 끝나는 원소 추출
grep(pattern = "a$", x = text3, value = TRUE)

# __ "a"또는 "b"를 포함하는 원소 추출
grep(pattern = "a|b", x = text3, value = TRUE)

# grepl() 함수의 활용
grepl(pattern = "b", x = text3)
!grepl(pattern = "b", x = text3)

# gregexpr() 함수의 이해
gregexpr(pattern = "[0-9]", text = text1)
regmatches(x = text1, 
           m = gregexpr(pattern = "[0-9]", text = text1))

unlist(regmatches(x = text1, 
                  m = gregexpr(pattern = "[0-9]", text = text1)))


# Q. 위 코드를 text_extractor() 라는 사용자 함수로 만들어보시오.
#    해당 함수는 입력되는 텍스트(1차원 벡터), 정규표현식. 
#    총 두 개의 인자(argument)를 갖는다.

# ~ 16:10

text_extractor = function(text, pattern){
  regmatches(x = text,
             m = gregexpr(pattern = pattern, text = text))
}

text_extractor = function(pattern, text){
  result = regmatches(x = text,
                      m = gregexpr(pattern = pattern, 
                                   text = text))
  return(unlist(result))
}

text_extractor(pattern = "[0-9]", text = text1)
text_extractor("[0-9]", text1)

# install.packages("stringr")
library("stringr")
str_extract_all(string = text1, pattern = "[0-9]")
str_extract_all(string = text1, pattern = "[0-9]{1,}")
str_extract_all(string = text1, pattern = "[0-9]{1,}")[[1]]
unlist(str_extract_all(string = text1, pattern = "[0-9]{1,}"))
