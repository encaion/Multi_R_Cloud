# "bike.csv"파일을 사용하여 다음의 문제를 풀이하시오. ~ 09:50
df = read.csv("bike.csv")
head(df, 2)

# Q1. humidity는 상대습도를 의미한다. 이 때
#    humidity가 100인 경우 비 또는 눈이 내렸을 가능성이 매우 높다.
#    humidity가 100인 경우는 1, 나머지는 0인 "is_rain" 변수를 만드시오.
df[, "is_rain"] = ifelse(test = df$humidity == 100, yes = 1, no = 0)

# Q2. 일별 is_rain의 합을 산출하여 bike_rain 객체에 저장하시오.
library("lubridate")
ymd_hms(df[1, 1])
as.Date(df[1, 1])

df[, "date"] = date(df$datetime)
head(df, 2)

bike_rain = aggregate(data = df, is_rain ~ date, FUN = "sum")
head(bike_rain)

# Q3. is_rain의 값이 1 이상인 경우 해당 일자는 비가 왔다고 할 때
#     월별 강우일자의 평균을 구하시오.
table(bike_rain$is_rain)
bike_rain[, "month"] = month(bike_rain$date)
head(bike_rain)
bike_rain[, "is_rain_day"] = ifelse(bike_rain$is_rain == 1, 1, 0)

bike_rain[, "year"] = year(bike_rain$date)
bike_rain_agg = aggregate(data = bike_rain, 
                          is_rain_day ~ year + month, 
                          FUN = "sum")
head(bike_rain_agg, 2)
aggregate(data = bike_rain_agg, is_rain_day ~ month, FUN = "mean")


#### 공공데이터 API ####
url_base = "http://openapi.molit.go.kr/OpenAPI_ToolInstallPackage/service/rest/RTMSOBJSvc/getRTMSDataSvcAptTradeDev?"
serviceKey = "Bk7EYrKKdxlarCe3OIShvWZ%2BHAUiSCKgR2dpgUk8MOgX6maAKWzDK4Pp2EapWX6GHOZRO%2BL72p9o6cREOHEWGw%3D%3D"
pageNo = 1
numOfRows = 10
LAWD_CD = "11110"
DEAL_YMD = "201912"

url = paste0(url_base,
             "serviceKey=", serviceKey, "&",
             "pageNo=", pageNo, "&",
             "numOfRows=", numOfRows, "&",
             "LAWD_CD=", LAWD_CD, "&",
             "DEAL_YMD=", DEAL_YMD)
url

api_result = readLines(url, encoding = "UTF-8", warn = FALSE)
head(api_result)

# install.packages("rvest")
library("rvest")
text = read_html(url, encoding = "UTF-8")
text

# %>% : 파이프라인 연산자, [Ctrl] + [Shift] + [m]
text %>% 
  html_children()

text %>% 
  html_children() %>% 
  html_children()

text %>% 
  html_children() %>% 
  html_children() %>% 
  html_children()

text %>% 
  html_nodes("item") %>%  
  .[1] %>%  
  html_text()

text %>% 
  html_nodes("item") %>%  
  .[1] %>% 
  html_text() %>%  
  strsplit(split = ">")

text %>%  
  html_text()

#### 네이버 ####
library("rvest")
url = "https://search.naver.com/search.naver?query=%EC%BD%94%EB%A1%9C%EB%82%98&where=news&ie=utf8&sm=nws_hty"

text = read_html(url, encoding = "UTF-8")
text

text %>% 
  html_nodes(xpath = "//*[@id='sp_nws1']/div[1]/div/a") %>%  
  html_text()

text %>% 
  html_nodes(xpath = "//*[@id='sp_nws1']") %>%  
  html_children()
  
text %>% 
  html_nodes(xpath = "//*[@id='sp_nws1']/div[1]/div/a") %>%  
  html_attr(name = "href")

text %>%  
  html_nodes(xpath = '//*[@id="sp_nws1"]/div[2]/ul/li[1]/span/a')

text %>%  
  html_nodes(xpath = '//*[@id="sp_nws1"]/div[2]/ul/li[1]/span/a') %>%  
  html_text()

# listt$div[2]$ul$li
