dir.create("elec_load_split")
list.files(pattern = "elec")

paste0("abc", ".", "csv")

number = 12
paste0("name_", number, ".csv")

df = iris
head(df, 2)

write.csv(df, "iris_write.csv", row.names = FALSE)
write.csv(df, "elec_load_split/iris_write.csv", row.names = FALSE)

# Q1. elec_load.csv 파일을 불러와서 
#     연도별 데이터를 분리하여 별도의 파일로 저장하시오.
#     해당 파일은 elec_load_split 폴더 내에 저장하시오.
#  단, 파일명에는 연도가 명시되어야 한다.
#  ex. elec_load_year_2020.csv

elec = read.csv("elec_load.csv")
head(elec, 2)
for(n_num in min(elec$YEAR):max(elec$YEAR)){
  elec_year = elec[elec$YEAR == n_num, ]
  write.csv(elec_year, paste0("elec_load_split/elec_load_year_", n_num, ".csv"))
}


elec_year = unique(elec$YEAR)
for(year in elec_year){
  write.csv(elec[elec$YEAR == year, ],
            paste0("elec_load_split/elec_load_year_", year, ".csv"),
            row.names = FALSE)
}

for(year in unique(elec$YEAR)){
  write.csv(elec[elec$YEAR == year, ],
            paste0("elec_load_split/elec_load_year_", year, ".csv"),
            row.names = FALSE)
}

# Q2. elec_load_split 폴더에 있는 elec로 시작하는 파일만을 골라 읽어온 후
#     하나의 데이터로 합치시오.
list.files(path = "elec_load_split/",
           pattern = "^elec") # elec로 시작하는 파일

# elec_sub = read.csv("elec_load_year_2008.csv") # xxx
elec_sub = read.csv("elec_load_split/elec_load_year_2008.csv")

list.files(path = "elec_load_split/",
           pattern = "^elec",
           full.names = TRUE)

file_list = list.files(path ="elec_load_split/",
                       pattern = "^elec",
                       full.names = TRUE)
elec = data.frame()
for(file_name in file_list){
  elec = rbind(elec, read.csv(file_name))
}


file_list = list.files(path ="elec_load_split/",
                       pattern = "^elec",
                       full.names = TRUE)
elec = data.frame()
for(file_name in file_list){
  elec_sub = read.csv(file_name)
  elec = rbind(elec, elec_sub)
}

bike = read.csv("bike.csv")
head(bike, 2)
# Q3. bike.csv 파일을 불러와서 시간대별 casual 변수의 평균값을 
#     사용하여 그래프를 그리시오.
#   - 그래프는 ggplot2의 막대그래프를 사용
#   - y축 값을 기준으로 막대를 색칠 할 것
library("lubridate")
library("ggplot2")
bike[, "hour"] = hour(bike$datetime)
bike_agg = aggregate(data = bike, casual ~ hour, FUN = "mean")
ggplot(data = bike_agg,
       aes(x = hour, y = casual, fill = casual)) + 
  geom_col()

# Q4. bike.csv 파일을 불러와서 시간대별 registered 변수의 평균값을 
#     사용하여 그래프를 그리시오.
#   - 그래프는 ggplot2의 막대그래프를 사용
#   - y축 값을 기준으로 막대를 색칠 할 것

bike_agg = aggregate(data = bike, registered ~ hour, FUN = "mean")
ggplot(data = bike_agg,
       aes(x = hour, y = registered, fill = registered)) + 
  geom_col()


bike_agg = aggregate(data = bike[, c("casual", "registered", "hour")], 
                     . ~ hour, FUN = "mean")
head(bike_agg)

library("reshape2")
bike_agg_melt = melt(data = bike_agg, id.vars = "hour")
head(bike_agg_melt, 2)
ggplot(data = bike_agg_melt,
       aes(x = hour, y = value, fill = value)) + 
  geom_col() + 
  facet_wrap(~ variable, ncol = 1, scales = "free_y") + 
  theme_bw() + 
  theme(legend.position = "none")


# install.packages("rgdal")
library("rgdal")
map = readOGR("2013_si_do.shp", verbose = FALSE)
class(map)

map$name
map$name_eng
map@data$name
map@polygons[[1]]@Polygons[[1]]@coords[1:3, ]

map_kor = fortify(map)
head(map_kor)

ggplot(data = map_kor,
       aes(x = long, y = lat,
           group = group)) + 
  geom_polygon(fill = "#FFFFFF",
               color = "#000000")


ggplot(data = map_kor,
       aes(x = long, y = lat,
           group = group)) + 
  geom_polygon(fill = "#FFFFFF",
               color = "#000000") + 
  theme(panel.background = element_rect(fill = "#82F6FF"))


map$name

map_seoul = map_kor[map_kor$id == 16, ]
ggplot(data = map_seoul,
       aes(x = long, y = lat,
           group = group)) + 
  geom_polygon(fill = "#FFFFFF",
               color = "#000000") + 
  theme(panel.background = element_rect(fill = "#82F6FF"))

map_jeju = map_kor[map_kor$id == 0, ]
ggplot(data = map_jeju,
       aes(x = long, y = lat,
           group = group)) + 
  geom_polygon(fill = "#FFFFFF",
               color = "#000000") + 
  theme(panel.background = element_rect(fill = "#82F6FF"))

# install.packages("geosphere")
library("geosphere")
centroid_jeju = centroid(map_jeju[, c("long", "lat")])

ggplot(data = map_jeju,
       aes(x = long, y = lat,
           group = group)) + 
  geom_polygon(fill = "#FFFFFF",
               color = "#000000") + 
  theme(panel.background = element_rect(fill = "#82F6FF")) + 
  annotate(geom = "point",
           x = centroid_jeju[1, 1],
           y = centroid_jeju[1, 2],
           size = 3, color = "#FF0000")

#### 공공데이터 API ####
url_sample = "http://openapi.molit.go.kr/OpenAPI_ToolInstallPackage/service/rest/RTMSOBJSvc/getRTMSDataSvcAptTradeDev?serviceKey=Bk7EYrKKdxlarCe3OIShvWZ%2BHAUiSCKgR2dpgUk8MOgX6maAKWzDK4Pp2EapWX6GHOZRO%2BL72p9o6cREOHEWGw%3D%3D&pageNo=1&numOfRows=10&LAWD_CD=11110&DEAL_YMD=201512"

# http://openapi.molit.go.kr/OpenAPI_ToolInstallPackage/service/rest/RTMSOBJSvc/getRTMSDataSvcAptTradeDev?
# serviceKey=Bk7EYrKKdxlarCe3OIShvWZ%2BHAUiSCKgR2dpgUk8MOgX6maAKWzDK4Pp2EapWX6GHOZRO%2BL72p9o6cREOHEWGw%3D%3D&
# pageNo=1&
# numOfRows=10&
# LAWD_CD=11110&
# DEAL_YMD=201512

url_sample2 = paste0("http://openapi.molit.go.kr/OpenAPI_ToolInstallPackage/service/rest/RTMSOBJSvc/getRTMSDataSvcAptTradeDev?",
                     "serviceKey=Bk7EYrKKdxlarCe3OIShvWZ%2BHAUiSCKgR2dpgUk8MOgX6maAKWzDK4Pp2EapWX6GHOZRO%2BL72p9o6cREOHEWGw%3D%3D&",
                     "pageNo=1&",
                     "numOfRows=10&",
                     "LAWD_CD=11110&",
                     "DEAL_YMD=201912")
url_sample2

api_result = readLines(url_sample2, encoding = "UTF-8")
head(api_result)

code = readLines("법정동코드 전체자료.txt")
head(code)

code = read.csv("법정동코드 전체자료.txt", sep = "\t")
head(code)

options(scipen = 1000) # (어정쩡하게) 큰 수를 요약표기 하는 것을 방지.
code_sigu = code[grep(pattern = "0{5,}$", code$법정동코드), ]
code_sigu = code_sigu[code_sigu$폐지여부 == "존재", ]
head(code_sigu)
tail(code_sigu)

as.character(code$법정동코드)

code_sigu[grep(pattern = "0{7,}$", code_sigu$법정동코드), ]
code_sigu[grep(pattern = "^[1-9]{2}0{8}$", code_sigu$법정동코드), ]

code_sigu = code_sigu[!grepl(pattern = "^[1-9]{2}0{8}$", code_sigu$법정동코드), ]
nrow(code_sigu)
head(code_sigu)

df_code = data.frame(cd = substr(code_sigu$법정동코드, start = 1, stop = 5),
                     name_kr = code_sigu$법정동명)
head(df_code, 2)

# write.csv(df_code, "code_book_sigungu.csv", row.names = FALSE)

# ★ 상황!
# 2015년 1월 부터 2019년 12월 까지 수집하고 싶음!
# 6자리 숫자로된 날짜가 필요함.
list_date = paste0(rep(2015:2019, each = 12), 
                   sprintf(fmt = "%02d", 1:12))
list_date

sprintf(fmt = "%03d", 1:12)

url_base = "http://openapi.molit.go.kr/OpenAPI_ToolInstallPackage/service/rest/RTMSOBJSvc/getRTMSDataSvcAptTradeDev?"
serviceKey = "Bk7EYrKKdxlarCe3OIShvWZ%2BHAUiSCKgR2dpgUk8MOgX6maAKWzDK4Pp2EapWX6GHOZRO%2BL72p9o6cREOHEWGw%3D%3D"
pageNo = 1
numOfRows = 10
LAWD_CD = "11110"
DEAL_YMD = "201912"

url = paste0(url_base,
             "serviceKey=", serviceKey, "&",
             "pageNo=", pageNo, "&",
             "numOfRows=", numOfRows, "&",
             "LAWD_CD=", LAWD_CD, "&",
             "DEAL_YMD=", DEAL_YMD)
url

api_result = readLines(url, encoding = "UTF-8", warn = FALSE)
head(api_result)

