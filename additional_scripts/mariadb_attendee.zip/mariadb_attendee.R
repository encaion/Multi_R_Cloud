library("DBI")
library("RMariaDB")
drv = dbDriver("MariaDB")
con = dbConnect(drv = drv,
                host = "test.cqavsxe3hmq4.ap-northeast-2.rds.amazonaws.com",
                port = 3306,
                # dbname = "test",
                user = "rcloudedu",
                password = "rcloudedu")
dbGetQuery(conn = con, "SHOW databases")
dbSendQuery(conn = con, "USE test")
dbSendQuery(conn = con, "set names 'utf8'") 
dbListTables(conn = con)

head(iris, 2)

dbWriteTable(conn = con, name = "iris",
             value = iris)
dbListTables(conn = con)

iris_sub = dbGetQuery(conn = con, "SELECT * FROM iris WHERE Species = 'setosa'")
nrow(iris_sub)
head(iris_sub)

# Q. bike.csv를 bike라는 이름의 테이블로 test db에 업로드 하고,
#    업로드된 bike 테이블에서 weather값이 2인 데이터만 추출하여
#    bike_w2 객체에 저장하시오.
bike = read.csv("bike.csv")
dbWriteTable(conn = con, name = "bike", value = bike)
dbListTables(conn = con)
bike_w2 = dbGetQuery(conn = con, "SELECT * FROM bike WHERE weather = '2'")
head(bike_w2)
nrow(bike_w2)

dbGetQuery(conn = con, 
           "SELECT datetime, season, holiday FROM bike WHERE weather = '2' LIMIT 3")

dbGetQuery(conn = con, 
           "SELECT datetime, season, holiday AS day_h
           FROM bike WHERE weather = '2' LIMIT 3")

dbGetQuery(conn = con, 
           "SELECT season, AVG(registered) AS registered_mean
           FROM bike GROUP BY season")

aggregate(data = bike, registered ~ season, FUN = "mean")

# 어느위치에서나 접근 가능한(%) 사용자 edu1 이라는 ID를 생성하고(create user 'edu1'@'%')
# 해당 ID의 비밀번호는 edu1로 한다(identified by 'edu1').
dbSendQuery(conn = con, "create user 'edu1'@'%' identified by 'edu1'")
