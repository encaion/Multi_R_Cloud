getwd()
list.files()
list.files(pattern = "csv$") # csv로 끝나는 파일명 출력
# 정규표현식에서 $는 ~~으로 끝나는~~ 을 의미.

listt = list(aa = 1:4,
             bb = matrix(1:4, nrow = 2),
             cc = list(dd = data.frame(xx = 1:3,
                                       yy = 1:3),
                       ee = 3:5))
listt
str(listt)
listt$bb[,1]
listt$cc$dd
listt$cc$dd[1:2, 1:2]

aws = read.csv("AWS_sample.txt", sep = "#")
head(aws, 2)

aws[1:2, ] = 999
head(aws, 4)

file_list = list.files(pattern = "csv$")
for(file_name in file_list){
  print(file_name)
  Sys.sleep(0.5)
}

df_1 = data.frame(aa = letters[1:4],
                  bb = 1:4)
df_1

df_1[df_1$bb >= 3, ]
df_1[c(FALSE, FALSE, TRUE, TRUE), ]

df_1[(df_1$aa == "a") | (df_1$aa == "c"),]
# "a" 또는 "c"를 만족


df = airquality
head(df, 2)

TRUE
FALSE
!TRUE
!FALSE
!c(TRUE, FALSE, FALSE)

install.packages("ggplot2")
library("ggplot2")
df = as.data.frame(diamonds)
head(df, 2)
table(df$cut, df$clarity)

table(df$cut)
prop.table(table(df$cut))
round(prop.table(table(df$cut)) * 100, 2)
df_tbl = as.data.frame(table(df$cut))
df_tbl
# Q. Freq의 각 원소의 비율을 계산하여
#    df_tbl 객체의 Prop라는 변수에 저장하시오.
Prop = "asdfasdf" # <-- Prop이라는 객체에 저장~~
df_tbl[, "Prop"] = df_tbl$Freq / sum(df_tbl$Freq) # 1
df_tbl$Prop = df_tbl$Freq / sum(df_tbl$Freq) # 2
df_tbl[, "Prop"] = prop.table(table(df$cut))[, 2] # 3
df_tbl

length(c(2, 4, 6))
unique(c(1, 1, 2, 3, 4, 4))
length(unique(c(1, 1, 2, 3, 4, 4)))

df = airquality
mean(df$Wind)
aggregate(data = df, Wind ~ Month, FUN = "mean")
head(df, 2)
aggregate(data = df, Wind ~ Month + Day, FUN = "mean")

bike = read.csv("bike.csv")
head(bike, 2)
# Q1. season 변수별 temp의 평균을 구하고
#     temp평균이 가장 높은 season은?
aggregate(data = bike, temp ~ season, FUN = "mean")
bike_agg = aggregate(data = bike, temp ~ season, FUN = "mean")
bike_agg[bike_agg$temp == max(bike_agg$temp), ]
bike_agg[bike_agg$temp == max(bike_agg$temp), "season"] # 1
bike_agg[which.max(bike_agg$temp), "season"] # 2

which.max(bike_agg$temp)

# Q2. holiday변수에는 값이 몇 종류가 들어있는가?
length(unique(bike$holiday))

# Q3. weather변수에는 값이 몇 종류가 들어있는가?
length(unique(bike$weather))

# Q4. season별 weather별 casual변수의 평균을 구하시오.
aggregate(data = bike, casual ~ season + weather, FUN = "mean")

bike_agg = aggregate(data = bike, casual ~ season + weather, FUN = "mean")
ggplot(data = bike_agg,
       aes(x = weather,
           y = casual,
           fill = casual)) + 
  geom_col() + 
  facet_wrap(~ season) + 
  theme_bw() + 
  theme(legend.position = "none")


vec = 1:6
vec >= 4
ifelse(test = vec >= 4, yes = "upper", no = "under")
ifelse(test = vec >= 4, yes = 1, no = 0)
(vec >= 4) + 0
(vec >= 4) * 1

ifelse(test = vec >= 4, yes = 1, no = vec)

list.files(pattern = "ra")

df = read.csv("rating_ramyun.csv")
head(df, 2)

df[, "kr"] = ifelse(df$Country == "South Korea",
                    yes = 1, no = 0)
head(df)

score = read.csv("class_score.csv")
head(score)

apply(score[, 5:9], MARGIN = 2, FUN = "max")

score_min = apply(score[, 5:9], MARGIN = 2, FUN = "min")
score_max = apply(score[, 5:9], MARGIN = 2, FUN = "max")
score_avg = apply(score[, 5:9], MARGIN = 2, FUN = "mean")

df_subject = data.frame(subject = colnames(score)[5:9],
                        min = score_min,
                        max = score_max,
                        avg = score_avg)
rownames(df_subject) = NULL # <-- row name 초기화
df_subject


# install.packages("DBI")
# install.packages("RMariaDB")

library("DBI")
library("RMariaDB")
drv = dbDriver("MariaDB")
con = dbConnect(drv = drv,
                host = "db-edu.cqavsxe3hmq4.ap-northeast-2.rds.amazonaws.com",
                port = 3306,
                dbname = "test",
                user = "edu4",
                password = "edu4") # 1~5
dbGetQuery(conn = con, "SHOW databases") # 데이터베이스 목록
dbSendQuery(conn = con, "USE test") # 특정 데이터베이스 사용
dbSendQuery(conn = con, "set names 'utf8'") 
dbListTables(conn = con)

dbGetQuery(conn = con, "SELECT * FROM diamonds LIMIT 3")
dia_sub = dbGetQuery(conn = con, "SELECT * FROM diamonds LIMIT 3")
head(dia_sub, 2)

dia_col_E = dbGetQuery(conn = con, 
                       "SELECT * FROM diamonds WHERE color = 'E'")
unique(dia_col_E$color)
nrow(dia_col_E)

db_url = "db-edu.cqavsxe3hmq4.ap-northeast-2.rds.amazonaws.com"
db_port = 3306
con = dbConnect(drv = drv,
                host = db_url,
                port = db_port,
                dbname = "test",
                user = "edu4",
                password = "edu4")

source("data_generator_join.R", encoding = "UTF-8")
head(df_room)

library("dplyr") # data plyr
left_join(x = df_list, y = df_room,
          by = c("member" = "name")) # 공통 key 매칭

strptime("2020년 11월 10일", format = "%Y년 %m월 %d일")
as.Date(44000, origin = "1900-01-01")

library("lubridate")
ymd("2020-11-10")
class(ymd("2020-11-10"))

ymd("20201110")
ymd(20201110)
ymd("201110")
ymd("2020/11/10")
ymd("2020.11.10")

wday("2020-11-10")
wday("2020-11-10", label = TRUE)

wday("2020-11-10", week_start = 1)
wday("2020-11-10", label = TRUE, week_start = 1)

bike = read.csv("bike.csv")
head(bike, 2)

# Q1. 요일별 registered의 평균값을 구하시오.
bike[, "wday"] = wday(bike$datetime, label = TRUE)
head(bike, 2)

aggregate(data = bike, registered ~ wday, FUN = "mean")

# Q2. 월별 casual의 평균값을 구하시오.
bike[, "month"] = month(bike$datetime)
head(bike, 2)

aggregate(data = bike, casual ~ month, FUN = "mean")

library("reshape2")

set.seed(123)
sample(1:45, size = 6)

elec = read.csv("elec_load.csv")
elec_melt = melt(data = elec,
                 id.vars = c("YEAR", "MONTH", "DAY"))
head(elec_melt)

colnames(elec_melt)[c(4, 5)] = c("HOUR", "LOAD")
head(elec_melt, 2)

head(elec, 2)
t(t(colnames(elec)))

elec_melt[, "HOUR"] = gsub(pattern = "X|HR", 
                           replacement = "", 
                           x = elec_melt$HOUR)
head(elec_melt)
class(elec_melt$HOUR)

elec_melt[, "HOUR"] = as.numeric(elec_melt$HOUR)
class(elec_melt$HOUR)

library("ggplot2")
a <- ggplot(economics, aes(date, unemploy)) 
a + geom_path(lineend="butt",
              linejoin="round", linemitre=1)


data_point = data.frame(xx = 1:10,
                        yy = 1:10)

ggplot(data = data_point,
       mapping = aes(x = xx, y = yy)) + 
  geom_point()

ggplot(data = data_point,
       mapping = aes(x = xx, y = yy)) + 
  geom_line()

ggplot(data = data_point,
       mapping = aes(x = xx, y = yy)) + 
  geom_col()


ggplot(data = data_point,
       mapping = aes(x = xx, y = yy)) + 
  geom_point(size = 10,
             color = "red")
colors()

set.seed(123)
line_df = data.frame(obs = 1:30,
                     var_1 = rep(c("A", "B", "C"), 10),
                     value = sample(1:100, size = 10))
head(line_df, 3)

ggplot(data = line_df,
       aes(x = obs, y = value)) + 
  geom_line()

ggplot(data = line_df,
       aes(x = obs, y = value, group = var_1)) + 
  geom_line()

ggplot(data = line_df,
       aes(x = obs, y = value, group = var_1,
           color = var_1)) + 
  geom_line()

ggplot(data = line_df,
       aes(x = obs, y = value, group = var_1,
           color = var_1)) + 
  geom_line() + 
  geom_point()

ggplot(data = line_df,
       aes(x = obs, y = value, group = var_1,
           color = var_1)) + 
  geom_line(size = 1.2) + 
  geom_point(size = 3)

# ggsave()


#### 10. 색상의 이해와 조합 ####
#### __ [03] 고급 그래프 실습 ####
#### _____ ● 제품 및 브랜드 평가 ####
# http://rstudio-pubs-static.s3.amazonaws.com/225516_35d03c8e153242cba01b723f1e3bcfff.html
library("dplyr")
library("ggplot2")

df = read.csv("prods_scores.csv", stringsAsFactors = FALSE)
df[, "score_phrase"] = factor(df$score_phrase,
                              levels = c("Disaster", "Unbearable", "Painful", "Awful", "Bad",
                                         "Mediocre",
                                         "Okay", "Good", "Great", "Amazing", "Masterpiece"))

Microsoft = paste0("Xbox", c(" One", "", " 360"))
Sony = paste0("PlayStation", c(" Portable", " 4", " 2", " 3", " Vita", ""))
PC = c("Linux", "Macintosh", "SteamOS", "PC")
Nintendo = c(paste0("Nintendo ", c("3DS", 64, "64DD", "DS", "DSi")),
             "New Nintendo 3DS",
             paste0("Game Boy", c("", " Color", " Advance")),
             "Wii",
             "Wii U",
             "NES",
             "GameCube",
             "Super NES")

df[, "company"] = ifelse(df$platform %in% Microsoft, "Microsoft",
                         ifelse(df$platform %in% Sony, "Sony",
                                ifelse(df$platform %in% PC, "PC",
                                       ifelse(df$platform %in% Nintendo,
                                              "Nintendo", "Other"))))

my.palette = c("Sony"      = "#EDC951",
               "Nintendo"  = "#EB6841",
               "PC"        = "#CC2A36",
               "Microsoft" = "#4F372D",
               "Other"     = "#00A0B0")

ggplot(data = df,
       aes(x = score_phrase,
           y = company,
           color = company)) +
  # geom_point(size = 10, alpha = 0.1) +
  geom_jitter(alpha = 0.15) +
  scale_color_manual(values = my.palette) +
  labs(x = "Score category", y = NULL, title = "Reviews by Score categories") +
  theme_bw() +
  theme(legend.position = "none",
        panel.grid.major = element_blank()) + 
  geom_vline(xintercept = (1:10) + 0.5,
             color = "#CCCCCC", linetype = 2) +
  geom_hline(yintercept = (1:4) + 0.5,
             color = "#CCCCCC", linetype = 2)
