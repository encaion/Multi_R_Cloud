df = read.csv("bike.csv")
head(df, 2)

# Q1. season 변수에는 몇 종류의 원소가 있는가?
unique(df$season)
length(unique(df$season))
# Q2. season별 temp의 최대값을 확인하시오
aggregate(data = df, temp ~ season, FUN = "max")

# Q3. season별 casual의 평균과 season별 registered의 평균을
#     구하고 각 평균의 차이값을 확인하시오
# (단, 결과는 데이터프레임 형태로 정리되어야 한다.)
# A1)
df_c = aggregate(data = df, casual ~ season, FUN = "mean")
df_r = aggregate(data = df, registered ~ season, FUN = "mean")

df_bind = cbind(df_c, df_r)
df_bind = df_bind[, -3]
df_bind

# A2)
df_bind = cbind(df_c, 
                registered = df_r$registered)
df_bind

# A3)
library("dplyr")
df_join = inner_join(x = df_c, y = df_r,
                     by = c("season" = "season"))
df_join

# A4) 
df_agg = aggregate(data = df[, c("season", "casual", "registered")],
                   . ~ season, FUN = "mean")
df_agg
# . 은 명시(선언)된 변수를 제외한 나머지 모든 변수

df_agg[, "diff"] = df_agg$casual - df_agg$registered
df_agg

# Q4. 월별 registered의 평균을 구하시오
head(df, 2)

library("lubridate")
df[, "month"] = month(df$datetime)
aggregate(data = df, registered ~ month, FUN = "mean")

# Q5. 주중 count의 평균과 주말 count의 평균을 구하고
#     각 평균값의 차이의 절대값을 반올림하여 소수점 둘 째 
#     자리 까지 표기하시오.
df[, "wday"] = wday(df$datetime, week_start = 1)
df[, "wend"] = ifelse(df$wday >= 6, yes = 1, no = 0)
head(df, 2)
# round("!?!?!", 2)
# round(abs("!?!?!"), 2)
# round(abs(mean("A") - mean("B")), 2)
mean_wend_0 = mean(df[df$wend == 0, "count"])
mean_wend_1 = mean(df[df$wend == 1, "count"])
round(abs(mean_wend_0 - mean_wend_1), 2)

mean_wend_0 = mean(df[df$wday <= 5, "count"])
mean_wend_1 = mean(df[df$wday >= 6, "count"])
round(abs(mean_wend_0 - mean_wend_1), 2)


# Q6. 시간대별 casual의 평균을 막대그래프로 그리시오
# (단, 평균값에 따라 다른 색상이 입혀지도록 지정)
head(df, 2)
df[, "hour"] = hour(df$datetime)
head(df, 2)
df_agg = aggregate(data = df, casual ~ hour, FUN = "mean")
head(df_agg)
ggplot(data = df_agg,
       aes(x = hour, y = casual, fill = casual)) + 
  geom_col()

# Q7. 시간대별 registered의 평균을 막대그래프로 그리시오
# (단, 평균값에 따라 다른 색상이 입혀지도록 지정)
df_agg = aggregate(data = df, registered ~ hour,
                   FUN = "mean")
ggplot(data = df_agg,
       aes(x = hour, y = registered, 
           fill = registered)) + 
  geom_col()

# Q8. 시간대별 casual과 registered의 평균을 
# 하나의 막대그래프로 표현하시오.
# (단, 평균값에 따라 다른 색상이 입혀지도록 지정)
# ※ reshape2 패키지의 melt() 함수 활용 권장
df[, "hour"] = hour(df$datetime)
df_sub = df[, c("hour", "casual", "registered")]
head(df_sub)

df_agg = aggregate(data = df_sub, . ~ hour, FUN = "mean")
head(df_agg)

ggplot(data = df_agg,
       aes(x = hour, y = casual, fill = casual)) + 
  geom_col()

ggplot(data = df_agg) + 
  geom_col(aes(x = hour, y = casual),
           fill = "#FF0000", alpha = 0.5) + 
  geom_col(aes(x = hour, y = registered),
           fill = "#0000FF", alpha = 0.5)

library("reshape2")
df_melt = melt(data = df_agg, id.vars = "hour")
head(df_melt)
ggplot(data = df_melt,
       aes(x = hour, y = value, fill = value)) + 
  geom_col() + 
  facet_wrap(~ variable, ncol = 1) +
  theme(legend.position = "none")

ggplot(data = df_melt,
       aes(x = hour, y = value, fill = value)) + 
  geom_col() + 
  facet_wrap(~ variable, ncol = 1, scales = "free_y") +
  theme(legend.position = "none")

