for(type in LETTERS){
  print(type)
}

?`%in%`
aggregate(data = iris, )
?aggregate

df = airquality
head(df, 2)

mean_sq = function(x){
  result = mean(x)^2
  return(result)
}
mean_sq(c(2, 4, 6, 9, 9, 8))

aggregate(data = df, Wind ~ Month, FUN = "mean_sq")
aggregate(data = df, Wind ~ Month,
          FUN = function(x){mean(x)^2}) # lambda 함수
# lambda 함수는 일회성 함수이며
# 그 연산이 매우 간단(1줄로 표현)할 때 주로 활용

mean_sqr = function(x, digit = 2){
  result = round(mean(x)^2, digits = digit)
  return(result)
}
mean_sqr(c(1, 4, 5, 7))
mean_sqr(c(1, 4, 5, 7), digit = 1)
aggregate(data = df, Wind ~ Month, 
          FUN = "mean_sqr")
aggregate(data = df, Wind ~ Month, 
          FUN = "mean_sqr", digit = 1)

score = read.csv("class_score.csv")
head(score, 2)

score[, "new_idx"] = apply(score[, 5:9], 1, FUN = "mean_sqr")
head(score, 2)

list.files(pattern = "\\.csv$") # .csv로 끝나는 파일 조회
list.files(pattern = "^bike") # bike로 시작하는 파일 조회
list.files(pattern = "sample") # sample 을 포함하는 파일 조회




library("ggplot2")

ggplot(data = diamonds, 
       aes(depth, fill = cut, color = cut)) + 
  geom_density(alpha = 0.2) + 
  xlim(55, 70) + 
  theme_bw()


ggplot(data = diamonds, 
       aes(depth, fill = cut, color = cut)) + 
  geom_density(alpha = 0.2) + 
  xlim(55, 70) + 
  theme(legend.position = "bottom") +
  theme_bw()

ggplot(data = diamonds, 
       aes(depth, fill = cut, color = cut)) + 
  geom_density(alpha = 0.2) + 
  xlim(55, 70) + 
  theme_bw() + 
  theme(legend.position = "bottom")

ggplot(diamonds, 
       aes(x = carat,
           y = price,
           color = cut)) + 
  geom_point() + 
  facet_wrap(~ cut, ncol = 3)

ggplot(diamonds, 
       aes(x = carat,
           y = price,
           color = cut)) + 
  geom_point() + 
  facet_wrap(~ cut, nrow = 1)

ggplot(diamonds, 
       aes(x = carat,
           y = price,
           color = cut)) + 
  geom_point(alpha = 0.15) + 
  facet_wrap(~ cut, nrow = 1) + 
  theme_bw() + 
  theme(legend.position = "none")



set.seed(123)
df_sample = data.frame(xx = 1:10,
                       yy = sample(1:15, size = 10))
ggplot(data = df_sample, 
       aes(x = xx, y = yy)) + 
  geom_point(size = 5)

ggplot(data = df_sample, 
       aes(x = xx, y = yy)) + 
  geom_point(size = 5, 
             shape = "★")

ggplot(data = df_sample, 
       aes(x = xx, y = yy)) + 
  geom_point(size = 5, 
             shape = "★") + 
  geom_hline(yintercept = 2:4, color = "#FF0000") + 
  geom_vline(xintercept = 2:4, color = "#0000FF")


ggplot(data = df_sample, 
       aes(x = xx, y = yy)) + 
  geom_hline(yintercept = 2:4, color = "#FF0000",
             size = 2) + 
  geom_vline(xintercept = 2:4, color = "#8888FF",
             size = 2) + 
  geom_point(size = 5, 
             shape = "★")

# install.packages("rgdal")
library("rgdal")

map = readOGR("2013_si_do.shp", verbose = FALSE)
map_kor = fortify(map) # data.frame으로 변환
head(map_kor)

map@data
nrow(map@data)
length(map@polygons)
map@polygons[17]
map@polygons[17][[1]]@ID

ggplot(data = map_kor,
       aes(x = long,
           y = lat,
           group = group)) + 
  geom_polygon(fill = "#FFFFFF",
               color = "#000000")

nrow(map_kor)
head(map_kor)
unique(map_kor$id)

ggplot(data = map_kor[map_kor$id == "8", ],
       aes(x = long,
           y = lat,
           group = group)) + 
  geom_polygon(fill = "#FFFFFF",
               color = "#000000")

map_loc = data.frame(id = rownames(map@data),
                     name = map@data$name)
map_loc


0.025 * 12
0.025 * 12 * 3

uri = "https://rcloud04071228.s3.ap-northeast-2.amazonaws.com/AWS_sample.txt"
aws = read.csv(uri, sep = "#")
head(aws)

# install.packages("aws.s3")
library("aws.s3")
source("aws_key.R", encoding = "UTF-8")
bucketlist()

Sys.getenv("AWS_ACCESS_KEY_ID")

my_b = bucketlist()[1, 1]
my_b

ls_obj = get_bucket(bucket = my_b)
ls_obj
# Key: 파일 또는 폴더의 경로

ls_obj[[1]]
ls_obj[[1]]$Key
ls_obj[[1]]$LastModified

library("lubridate")
ymd_hms(ls_obj[[1]]$LastModified)
ymd_hms(ls_obj[[1]]$LastModified,
        tz = "Asia/Seoul")

df = s3read_using(FUN = read.csv,
                  object = ls_obj[[1]]$Key, 
                  bucket = my_b)
head(df)

df = s3read_using(FUN = read.csv,
                  object = ls_obj[[1]]$Key, 
                  bucket = my_b,
                  sep = "#")
head(df)
