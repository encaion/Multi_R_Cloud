

1

# 주석(comment)
# 단축키: [Ctrl] + [Shift] + [C]

# 코드실행: [Ctrl] + [Enter]
123

# 12eeff ----

#### 1. 시작하기 ####
#### 2. 파일 불러오기 ####

# install.packages("beepr")
library("beepr")
beep(2)
beepr::beep(2)

# install.packages("data.table")
library("data.table")


aaa = function(x){}
aaa
aaa()

bbb = function(){
  print("Rloha")
}

bbb()

ccc = function(x){
  print(x)
}

ccc()
ccc(x = 123)
ccc(6576)

ddd = function(x){
  x + 3
}
ddd(12354125)

eee = function(x = 4){
  x * 5
}
eee()
eee(124)

fff = function(aa, bb){
  aa * bb
}

fff(aa = 1)
fff(aa = 1, bb = 3)

hhh = function(x){
  result = x^2 + 3
  return(result)
}
hhh(100)


source("new_fun_src.R")
new_fun(123)

getwd()

df = iris
head(df)

123
12
41
2
12000000000000000
0.00000000000156

'asdf'
"asdf"
# "asdf"sdgg"
"asdf\"sdgg"

TRUE
FALSE
TRUE + TRUE
FALSE + TRUE

c(1, 2, 3)
c(1, 2, "a")
aa = c(2, 5, 7)
aa
aa[1] # 첫 번째 원소 
aa[3] 
aa[c(1, 3)] # 1, 3번째
bb = aa # aa 를 bb에 복제
bb
bb[2] = "kk" # 두 번째 원소를 kk로 치환
bb

matrix(c(1, 3, 5, 7))
matrix(c(1, 3, 5, 7), nrow = 2)
matrix(c(1, 3, 5, 7), ncol = 2)
matrix(c(1, 3, 5, 7), nrow = 2, byrow = TRUE)
# n 접두사: number of ~ 

data.frame(aa = c(1, 2, 3),
           bb = c("a", "b", "c"))
data.frame(aa = c(1, 2, 3),
           bb = c("a", "b"))
df = data.frame(aa = c(1, 2, 3),
                bb = c("a", "b", "c"))
df
df$aa # df 데이터프레임 객체의 aa변수
df[, 1] # df 데이터프레임 객체의 첫 번째 변수
df[, "aa"] # df 데이터프레임 객체의 aa변수


listt = list(aa = c(1, 2, 3),
             bb = matrix(c(1, 3, 5, 7), nrow = 2),
             cc = list(dd = data.frame(xx = 1,
                                       yy = 2),
                       ee = c(2, 4, 6)))
listt
listt$aa # listt 리스트 객체의 하위 리스트 aa에 접근
listt[1] # listt 리스트 객체의 첫 번째 하위 리스트 aa에 접근
listt[[1]] # listt 리스트 객체의 첫 번째 하위 리스트 aa에 접근
str(listt) # 객체의 구조

is.na(c(1, 3, NA, 8))

as.numeric("123")
as.numeric("2,123")
as.numeric("2,123원")
as.numeric("2,123$")

library("data.table")
as.numeric("aa")
"a" + 1

"감자" == "고구마"
"감자" != "고구마"
TRUE
!TRUE
FALSE
!FALSE
tf = c(TRUE, FALSE, TRUE)
!tf

c(1, 2, 3, 4, 5)
1:5
6:2
2:-5

seq(1, 3)
seq(1, 3, 1)
seq(from = 1, to = 3)
seq(from = 1, to = 3, by = 1)

seq(from = 1, to = 3, length.out = 8)
seq(from = 1, to = 3, length.out = 9)

rep(1:3, 3)
rep(3, 1:3)
rep(x = 1:3, times = 3)
rep(times = 3, x = 1:3)


list.files()

# AWS_sample.txt 파일을 보조기억장치(HDD, SSD)에서
# 주 기억장치(RAM)으로 복사한 후 핸들링
aws = read.delim("AWS_sample.txt", sep = "#")
head(aws, 2)

aws = read.csv("AWS_sample.txt", sep = "#")
head(aws)

bike = read.csv("bike.csv")
head(bike)

library("data.table")
df = fread("bike.csv")
head(df, 2)
class(df)
df = as.data.frame(df)
class(df)
head(df, 2)

# install.packages("readxl")
library("readxl")
df = read_excel("iris_xlsx.xlsx")
head(df, 2)
class(df)
df = as.data.frame(df)
class(df)
head(df, 2)

write.csv(df, "write_csv_sample_01.csv")
write.csv(df, "write_csv_sample_02.csv", row.names = FALSE)

# iris: 세 종류 붓꽃(iris)의 꽃잎과 꽃받침 측정 데이터
#       종류별로 50개의 측정데이터가 있음.
iris[150, ] # <-- 마지막 row
nrow(iris) # iris 객체의 row 개수 확인


aws = read.csv("AWS_sample.txt", sep = "#")
str(aws)

letters
