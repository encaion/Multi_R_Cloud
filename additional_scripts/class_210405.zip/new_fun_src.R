new_fun = function(x){
  result = x + 1000
  return(result)
}