list.files(pattern = "\\.csv$")

paste("a", "b", "c")
paste("a", "b", "c", sep = "-")
paste(c("a", "b", "c"), sep = "-")
paste(c("a", "b", "c"), collapse = "-")
paste0("a", "b", "c")

paste0("sample_", 1:5, ".csv")

# Q1. 상기 코드를 반복문을 사용한 코드로 바꿔보시오.
# A1)
for(n in 1:5){
  print(paste0("sample_", n, ".csv"))
}
# A2)
vec = c()
for(n in 1:5){
  vec = c(vec, paste0("sample_", n, ".csv"))
}
vec
# A3)
lst <- list()
for(i in 1:5) {
  lst[[i]] = paste0("sample_", i, ".csv")
}

# Q2. 작업폴더의 파일 중 csv확장자인 파일을
#     순차적으로 불러오면서 상단 첫 두 개의 row를
#     출력하는 코드를 작성하시오.
# ※ for(), list.files() 함수 활용
file_list = list.files(pattern = "\\.csv$")
for(file_path in file_list){
  print(file_path)
  df_sub = read.csv(file_path)
  print(head(df_sub, 2))
}


dir.create("bike_set")
list.files(pattern = "bike")

bike = read.csv("bike.csv")
head(bike, 2)

bike_sub = bike[bike$season == 1, ]
write.csv(bike_sub, "bike_set/bike_season_1.csv",
          row.names = FALSE)
list.files(path = "bike_set")

# Q3. 상기 코드를 참고하여 bike.csv 파일을
#     season별로 분할하여 bike_set 폴더에
#     개별 파일로 저장하시오.
unique(bike$season)
for(season in 1:4){
  print(season)
}

for(season in unique(bike$season)){
  print(season)
}

for(season in unique(bike$season)){
  bike_sub = bike[bike$season == season, ]
  write.csv(bike_sub, 
            paste0("bike_set/bike_season_", season, ".csv"),
            row.names = FALSE)
}
list.files(path = "bike_set")


df = iris
head(df)

# Q4. iris_set 폴더를 생성하고
#     Species 별로 데이터 세트를 분리하여
#     iris_set 폴더 내부에 별도의 파일로 저장하시오.
# ※ for() 활용
dir.create("iris_set")
for(species in unique(df$Species)){
  df_sub = df[df$Species == species, ]
  write.csv(df_sub,
            paste0("iris_set/iris_species_", species, ".csv"),
            row.names = FALSE)
}
list.files(path = "iris_set/")


list.files(path = "iris_set/",
           full.names = TRUE)

list.files(path = "iris_set/",
           full.names = TRUE,
           recursive = TRUE) # <-- 하위폴더의 하위폴더~~ 까지

df = read.csv("iris_species_setosa.csv")
df = read.csv("iris_set/iris_species_setosa.csv")
# C:\Users\Encaion\Desktop\R_Class\iris_set
df = read.csv("C:/Users/Encaion/Desktop/R_Class/iris_set/iris_species_setosa.csv")

# 상대경로, 절대경로

file_list = list.files(path = "iris_set/",
                       full.names = TRUE)
df_sub = read.csv(file_list[1])
head(df_sub)

# Q5. 상기 코드를 참고하여 iris_set 폴더의 파일을 하나씩 읽어와서
#     df 객체에 합치고, 그 row 개수를 확인하시오.
# ※ for(), rbind() 함수 활용
file_list = list.files(path = "iris_set/",
                       full.names = TRUE)

df = data.frame()
for(file_path in file_list){
  print(file_path)
  df_sub = read.csv(file_path)
  print(nrow(df_sub))
  df = rbind(df, df_sub)
}
nrow(df)


library("aws.s3")
source("aws_key.R", encoding = "UTF-8")
bucketlist()

my_b = bucketlist()[1, 1]

ls_obj = get_bucket(bucket = my_b)
ls_obj

ls_obj[[1]]
ls_obj[[1]]$Key

for(n in 1:length(ls_obj)){
  print(ls_obj[[n]]$Key)
}

lapply(ls_obj, FUN = "[[", "Key") # 각 리스트의 Key 리스트에 접근
class(lapply(ls_obj, FUN = "[[", "Key"))
unlist(lapply(ls_obj, FUN = "[[", "Key")) # 리스트 구조를 벡터로

3 + 5
`+`(3, 5)
df[1, 2:3]
`[`(df, 1, 2:3)
'+'
`+`
df_sample = data.frame(aa = 1:3,
                       bb = 1:3)
df_sample
colnames(df_sample) = c("12ab", "adf ss")
df_sample
df_sample$`12ab`
df_sample$`adf ss`


vec_ls_obj = unlist(lapply(ls_obj, FUN = "[[", "Key"))
vec_ls_obj = vec_ls_obj[grep(pattern = "[^/]$", vec_ls_obj)]
vec_ls_obj
# 슬래시(/)를 제외한 나머지 모든 문자로 끝나는 원소

# Q. bucket 이름을 입력으로 하고, 해당 bucket의
#    모든 객체(파일) 목록을 출력값으로 하는
#    사용자 정의 함수 s3_obj_list() 를 생성하시오.

s3_obj_list = function(bucket){
  ls_obj = get_bucket(bucket = bucket)
  vec_ls_obj = unlist(lapply(ls_obj, FUN = "[[", "Key"))
  result = vec_ls_obj[grep(pattern = "[^/]$", vec_ls_obj)]
  return(result)
}
s3_obj_list(bucketlist()[1, 1])


s3write_using(iris[48:55, ],
              FUN = write.csv,
              object = "data/iris_subset.csv", # 파일 저장 경로
              bucket = bucketlist()[1, 1])
s3_obj_list(bucketlist()[1, 1])

s3write_using(iris[48:55, ],
              FUN = write.csv,
              object = "data/iris_subset_2.csv",
              bucket = bucketlist()[1, 1],
              row.names = FALSE) # write.csv 함수의 argument
s3_obj_list(bucketlist()[1, 1])

s3read_using(FUN = read.csv,
             object = "data/iris_subset.csv",
             bucket = bucketlist()[1, 1])

s3read_using(FUN = read.csv,
             object = "data/iris_subset_2.csv",
             bucket = bucketlist()[1, 1])


bike = read.csv("bike.csv")
head(bike, 2)

library("lubridate")
bike[, "wday"] = wday(bike$datetime, week_start = 1,
                      label = TRUE, abbr = TRUE)
head(bike, 2)

library("ggplot2")

# Q1. 요일별 casual의 평균을 막대그래프로 표현하고
#     그 평균값에 따라 자동으로 색상이 입혀지도록 하시오.
bike_agg_c = aggregate(data = bike, casual ~ wday,
                       FUN = "mean")
ggplot(data = bike_agg_c,
       aes(x = wday, y = casual, fill = casual)) + 
  geom_col()

# Q2. 요일별 registered의 평균을 막대그래프로 표현하고
#     그 평균값에 따라 자동으로 색상이 입혀지도록 하시오.
bike_agg_r = aggregate(data = bike, registered ~ wday,
                       FUN = "mean")
ggplot(data = bike_agg_r,
       aes(x = wday, y = registered, 
           fill = registered)) + 
  geom_col()


# Q3. Q1과 Q2의 그래프 내용을 한장의 이미지로 표현하시오.

bike_agg = aggregate(data = bike[, c("casual", "registered", "wday")], 
                     . ~ wday,
                     FUN = "mean")
head(bike_agg)
library("reshape2")
bike_agg_melt = melt(data = bike_agg, id.vars = "wday")
head(bike_agg_melt)

ggplot(data = bike_agg_melt,
       aes(x = wday, y = value, fill = value)) + 
  geom_col() + 
  facet_wrap( ~ variable, ncol = 1, scales = "free_y") + 
  theme_bw() + 
  theme(legend.position = "none")


list.files(path = "aws_key/",
           full.names = TRUE)

list.files(pattern = "법정동")
readLines("법정동코드 전체자료.txt", n = 2) # 첫 두 줄만 읽어옴

df = read.csv("법정동코드 전체자료.txt", sep = "\t")
head(df)

substr("서울특별시 종로구", start = 1, stop = 5)
substr("서울특별시 종로구", start = 7, stop = 9)

# Q1. 폐지여부 변수의 고유한 원소가 어떤 것이 있는지 확인하시오.
unique(df$폐지여부)
# Q2. 현재 사용되고 있는(존재) 법정동 코드만 필터링 하여 
#     df_sub객체에 저장하시오.
df_sub = df[df$폐지여부 == "존재", ]
head(df_sub)

# Q3. 법정동 코드 중 여섯 번째 숫자부터 마지막 숫자 까지
#     뽑아내어 별도의 변수(cd_end)에 저장하시오.
options(scipen = 100)
df_sub[, "cd_end"] = substr(df_sub$법정동코드, 
                            start = 6, stop = 10)
head(df_sub, 3)

# Q4. cd_end 값이 모두 0인 자료를 추출하여
#     df_sub_0 객체에 저장하고 그 row 개수를 확인하시오.
df_sub_0 = df_sub[df_sub$cd_end == "00000", ]
head(df_sub_0)
nrow(df_sub_0)
