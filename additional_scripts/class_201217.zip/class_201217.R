library("ggplot2")
bike = read.csv("bike.csv")
head(bike, 2)
library("lubridate")
bike[, "hour"] = hour(bike$datetime)
# Q1. 시간대별 casual의 평균을 구하여
#     df_agg_c 객체에 저장하시오.
df_agg_c = aggregate(data = bike, casual ~ hour, FUN = "mean")
# Q2. 시간대별 registered의 평균을 구하여
#     df_agg_r 객체에 저장하시오.
df_agg_r = aggregate(data = bike, registered ~ hour, FUN = "mean")

# Q3. df_agg_c와 df_agg_r을 rbind 하시오.
colnames(df_agg_c)[2] = "cnt_mean"
colnames(df_agg_r)[2] = "cnt_mean"
df_agg_c[, "type"] = "casual"
df_agg_r[, "type"] = "registered"
df_agg_bind = rbind(df_agg_c, df_agg_r)
head(df_agg_bind)

# Q4. df_agg_c 를 사용하여 막대 그래프를 그리시오.
#  ※ 색상은 산출한 평균값을 기반으로 자동 설정되게 하시오.
ggplot(data = df_agg_c,
       aes(x = hour, y = cnt_mean, 
           fill = cnt_mean)) + 
  geom_col()

# Q5. df_agg_r 를 사용하여 막대 그래프를 그리시오.
#  ※ 색상은 산출한 평균값을 기반으로 자동 설정되게 하시오.
# geom_col()
ggplot(data = df_agg_r,
       aes(x = hour, y = cnt_mean, 
           fill = cnt_mean)) + 
  geom_col()


df = as.data.frame(diamonds)
head(df, 2)

ggplot(data = df,
       aes(x = cut, y = price, 
           fill = cut)) + 
  geom_boxplot()

df_agg_cut = aggregate(data = df, price ~ cut, FUN = "mean")
df_agg_cut = df_agg_cut[order(df_agg_cut$price), ]
df_agg_cut[, "color_fill"] = 1:nrow(df_agg_cut)
df_agg_cut

library("dplyr")
df_join = left_join(x = df, y = df_agg_cut[, -2],
                    by = c("cut" = "cut"))
head(df_join)
ggplot(data = df_join, 
       aes(x = cut, y = price, 
           fill = color_fill)) + 
  geom_boxplot()


ggplot(data = df_join, 
       aes(x = cut, y = price, 
           fill = color_fill)) + 
  geom_boxplot() + 
  scale_fill_gradient(low = "#9972F5",
                      high = "#61D482")

ggplot(data = df_join, 
       aes(x = cut, y = price, 
           fill = color_fill)) + 
  geom_boxplot() + 
  scale_fill_gradient2(low = "#000000",
                       mid = "#FFFFFF", midpoint = 3,
                       high = "#61D482")

head(df_agg_bind)
ggplot(data = df_agg_bind,
       aes(x = hour, y = cnt_mean,
           fill = cnt_mean)) + 
  geom_col()

ggplot(data = df_agg_bind,
       aes(x = hour, y = cnt_mean,
           fill = cnt_mean)) + 
  geom_col() + 
  facet_wrap(~ type)

ggplot(data = df_agg_bind,
       aes(x = hour, y = cnt_mean,
           fill = cnt_mean)) + 
  geom_col() + 
  facet_wrap(type ~ ., ncol = 1,
             scales = "free_y")

install.packages("rgdal")
library("rgdal")
library("ggplot2")
map = readOGR("2013_si_do.shp", verbose = FALSE)
map_kor = fortify(map)
head(map_kor)

ggplot(data = map_kor,
       aes(x = long, y = lat,
           group = group)) + 
  geom_polygon(fill = "#FFFFFF",
               color = "#000000")

map_kor_sub = map_kor[map_kor$long < 130, ]
map_kor_sub = map_kor_sub[map_kor_sub$long > 125.6, ]
ggplot(data = map_kor_sub,
       aes(x = long, y = lat,
           group = group)) + 
  geom_polygon(fill = "#FFFFFF",
               color = "#000000")

map@data
ggplot(data = map_kor[map_kor$id == 16, ],
       aes(x = long, y = lat,
           group = group)) + 
  geom_polygon(fill = "#FFFFFF",
               color = "#000000")


ggplot(data = map_kor,
       aes(x = long, y = lat,
           group = group,
           fill = id)) + 
  geom_polygon(color = "#000000") + 
  guides(fill = guide_legend(ncol = 2))

url_main = "https://opendart.fss.or.kr/api/corpCode.xml"
url_arg_01 = "crtfc_key"
mykey = "fca349b71625ff8c453d"

url = paste0(url_main, "?", url_arg_01, "=", mykey)

download.file(url = url,
              destfile = "corpcode.zip", 
              method = "curl")

unzip(zipfile = "corpcode.zip")
list.files(pattern = "xml$")


library("rvest")
text = read_html("sample.xml", encoding = "UTF-8")
as.character(text)




