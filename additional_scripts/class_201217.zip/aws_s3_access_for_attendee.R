#### 1. Environment & connection ####
# install.packages("aws.s3")
source("00_environment.R", encoding = "UTF-8")
Sys.getenv("AWS_ACCESS_KEY_ID")

library("aws.s3")
#### 2. Object checking #### 
ls_bucket = bucketlist()
ls_bucket

bucket = ls_bucket[1, "Bucket"]

ls_object = get_bucket(bucket = bucket) # list.files()
str(ls_object)
ls_object[[1]][["Key"]]
ls_object[[2]][["Key"]]
ls_object[[3]][["Key"]]
length(ls_object)

# list.files(recursive = TRUE, full.names = TRUE)
2 + 4
`+`(2, 4)
`[`(ls_bucket, i = 1, j = 1)
ls_bucket[1, 1]

# Q1. 반복문을 사용하여 각 리스트 내부의 모든 key 정보를
# 취합하여 별도의 객체에 저장하시오.
file_list = c()
for(n in 1:length(ls_object)){
  file_list_sub = ls_object[[n]][["Key"]]
  file_list = c(file_list, file_list_sub)
}
file_list

file_list = lapply(X = ls_object, FUN = function(x){x[["Key"]]})
file_list = lapply(X = ls_object, FUN = `[[`, "Key")
file_list = unlist(file_list)

file_list_2 = grep(pattern = "[0-9]\\.csv$", x = file_list,
                   value = TRUE)
file_list_2

#### 3. Object Reading ####
#### __ 1) raw ####

#### __ 2) function ####
df_sample = s3read_using(FUN = read.csv,
                         object = file_list_2[1],
                         bucket = bucket)
head(df_sample)

df = data.frame()
for(n in 1:length(file_list_2)){
  df_sub = s3read_using(FUN = read.csv, object = file_list_2[n],
                        bucket = bucket)
  df = rbind(df, df_sub)
}
nrow(df)

#### 4. Object Writing ####
df_iris = iris
head(df_iris)

s3write_using(x = df_iris,
              FUN = write.csv,
              object = "iris.csv",
              bucket = bucket,
              row.names = FALSE)


#### 5. Object Delete ####
