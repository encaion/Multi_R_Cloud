# http://item.gmarket.co.kr/Item?goodscode=1918091615&ver=637438996539619639

# http://item.gmarket.co.kr/Item?
#   goodscode=1918091615
#   &ver=637438996539619639

# install.packages("tackscheduleR")

install.packages("excel.link")
library("excel.link")
xlrc[["a1"]] = 1:10

xl.sheet.add("new")
xl.sheet.activate("Sheet1")
xl.sheet.delete("new")
xlrc[["b2"]] = iris
xl.sheet.add("plot")
library("ggplot2")
qplot(1:10, 1:10)
xlrc[["c3"]] = current.graphics()

library("rvest")
text = read_html("CORPCODE.xml", encoding = "UTF-8")

text_sample = readLines("CORPCODE.xml", n = 20, encoding = "UTF-8")

text %>%  
  html_nodes("corp_code") %>%  
  html_text() -> vec_corp_code
head(vec_corp_code)

text %>% html_nodes("corp_code") %>% html_text() -> vec_corp_code
text %>% html_nodes("corp_name") %>% html_text() -> vec_corp_name
text %>% html_nodes("stock_code") %>% html_text() -> vec_stock_code
text %>% html_nodes("modify_date") %>% html_text() -> vec_modify_date
df_corp_code = data.frame(obs = 1:length(vec_corp_code),
                          corp_code = vec_corp_code,
                          corp_name = vec_corp_name,
                          stock_code = vec_stock_code,
                          modify_date = vec_modify_date)
head(df_corp_code)


text_sample = "<corp_code>00434003</corp_code>"
gsub(pattern = "<.*?>", replacement = "", text_sample)

