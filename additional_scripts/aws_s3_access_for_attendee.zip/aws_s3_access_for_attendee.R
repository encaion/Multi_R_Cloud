#### 1. Environment & connection ####
# install.packages("aws.s3")

#### 2. Object checking #### 

#### 3. Object Reading ####
#### __ 1) raw ####

#### __ 2) function ####

#### 4. Object Writing ####

#### 5. Object Delete ####
