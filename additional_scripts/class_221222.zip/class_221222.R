library("aws.s3")
source("00_environment.R")

bucketlist()

my_bucket = "multi-r-class-4925"
get_bucket(bucket = my_bucket)

df_score = s3read_using(FUN = read.csv,
                        object = "class_score.csv",
                        bucket = my_bucket)
head(df_score)

# install.packages("rvest")
library("rvest")
text = read_html("https://nip.kdca.go.kr/irgd/cov19stats.do?list=all")
text
html_text(text)
html_children(text)
html_children(html_children(text))

html_nodes(text, "datatime")
html_text(html_nodes(text, "datatime"))

data_time = html_text(html_nodes(text, "datatime"))
data_time

text %>% # [ctrl] + [shift] + [m]: 파이프 연산자 단축키
  html_nodes("datatime") %>% 
  html_text() -> data_time2

data_time2

# data_time2 <- text %>% 
#   html_nodes("datatime") %>% 
#   html_text()

text %>%  
  html_nodes("items") %>% 
  html_children() -> text_items

text_items[[1]]
text_items[[1]] %>%  
  html_children() %>%  
  html_text() -> value_sub

text_items[[1]] %>%  
  html_children() %>%  
  html_name() -> name_sub

df = data.frame()
for(n in 1:length(text_items)){
  text_items[[n]] %>% html_children() %>% html_text() -> value_sub
  text_items[[n]] %>% html_children() %>% html_name() -> name_sub
  df_sub = data.frame(t(value_sub))
  colnames(df_sub) = name_sub
  df = rbind(df, df_sub)
}
df

Sys.Date()
df = cbind(date1 = Sys.Date(), 
           date2 = data_time,
           df)
head(df, 2)

# install.packages("rgdal")
library("rgdal")
library("ggplot2")
map = readOGR("2013_si_do.shp")
map_kor = fortify(map)
head(map_kor)
ggplot(data = map_kor,
       aes(x = long, y = lat, group = group)) + 
  geom_polygon(fill = "#FFFFFF", color = "#000000")

map$code
iconv(map$name, from = "CP949", to = "UTF-8")

head(map@data, 3)
length(map@polygons)
length(map@polygons[[1]]@Polygons)
map@polygons[[1]]@Polygons[[2]]

head(map_kor, 2)
unique(map_kor$id)
head(map@data[, -2])

ggplot(data = map_kor[map_kor$id %in% c(1, 3, 5), ],
       aes(x = long, y = lat, group = group)) + 
  geom_polygon(fill = "#FFFFFF", color = "#000000")

ggplot(data = map_kor,
       aes(x = long, y = lat, group = group)) + 
  geom_polygon(fill = "#FFFFFF", color = "#000000")

map_kor2 = map_kor
map_kor2 = map_kor2[map_kor2$long < 130, ]
map_kor2 = map_kor2[map_kor2$long > 125.8, ]
ggplot(data = map_kor2,
       aes(x = long, y = lat, group = group)) + 
  geom_polygon(fill = "#FFFFFF", color = "#000000")

map_kor2[map_kor2$id == 0, "long"] = map_kor2[map_kor2$id == 0, "long"] + 2.5
map_kor2[map_kor2$id == 0, "lat" ] = map_kor2[map_kor2$id == 0, "lat" ] + 0.9
ggplot(data = map_kor2,
       aes(x = long, y = lat, group = group)) + 
  geom_polygon(fill = "#FFFFFF", color = "#000000")

ggplot(data = map_kor2[map_kor2$id == 16, ],
       aes(x = long, y = lat, group = group)) + 
  geom_polygon(fill = "#FFFFFF", color = "#000000")

new_loc = data.frame(long = 126.9542756,
                     lat = 37.4836721,
                     lab = "맛집")

ggplot() + 
  geom_polygon(data = map_kor2[map_kor2$id == 16, ],
               aes(x = long, y = lat, group = group),
               fill = "#FFFFFF", color = "#000000") + 
  geom_point(data = new_loc, 
             aes(x = long, y = lat),
             size = 3, color = "#FF0000") + 
  geom_text(data = new_loc,
            aes(x = long, y = lat + 0.03, 
                label = lab))
