
url_base = "http://openapi.molit.go.kr/OpenAPI_ToolInstallPackage/service/rest/RTMSOBJSvc/getRTMSDataSvcAptTradeDev?"
url_param = paste0("LAWD_CD=11110&DEAL_YMD=201512&serviceKey=",
                   "Bk7EYrKKdxlarCe3OIShvWZ%2BHAUiSCKgR2dpgUk8MOgX6maAKWzDK4Pp2EapWX6GHOZRO%2BL72p9o6cREOHEWGw%3D%3D")
url = paste0(url_base, url_param)
library("rvest")
text = read_html(url, encoding = "UTF-8")
text %>% 
  html_children() %>%  
  html_children() %>% 
  html_children()

df = read.csv("법정동코드 전체자료.txt", sep = "\t")
head(df)

options(scipen = 100)
df[, "cd_first"] = substr(df$법정동코드, start = 1, stop = 5)
unique(df$cd_first)

head(df, 2)

# 0이 5번 반복 되는 것으로 끝나는 패턴
df_sub = df[grep(pattern = "0{5}$", x = df$법정동코드), ]
head(df_sub)


options(scipen = 100)
df = read.csv("법정동코드 전체자료.txt", sep = "\t")
head(df)

df = df[df$폐지여부 == "존재", ]
df = df[grep(pattern = "0{5}$", x = df$법정동코드), ]
head(df)

df_sub = df[grepl(pattern = "0{8}$", x = df$법정동코드), ]
head(df_sub)

df_sub = df[!grepl(pattern = "0{8}$", x = df$법정동코드), ]
head(df_sub)

df_sub[, "cd"] = substr(df_sub$법정동코드, start = 1, stop = 5)
head(df_sub)

df_cd = df_sub[, c("cd", "법정동명")]
colnames(df_cd)[2] = "name_kr"
head(df_cd)
# write.csv(df_cd, "region_cd_name.csv", row.names = FALSE)

# query(질의)

# https://www.coupang.com/vp/products/1487807826?
# itemId=2554413862&
# vendorItemId=3002625520&
# isAddedCart=

# paste0()
# paste()

# glue::glue()

# install.packages("glue")
library("glue")
glue("naver.com?key={mykey}", mykey = "asdf")

data.frame(title = rep(c("aaa", "bbb"), each = 4),
           reply = letters[1:8])

text1 = "1234 asdfASDF  ㄱㄴㄷㄹㅏㅑㅓㅕ가나다라   .!@#"
text2 = "<a> <ab> <abc> <abcd>"
text3 = c("aaa", "bbb", "ccc", "abc")

text1

# gsub(): 패턴 매칭 및 치환
gsub(pattern = "[0-9]", replacement = "@", x = text1)
gsub(pattern = "[a-z]", replacement = "@", x = text1)
gsub(pattern = "[0-9]", replacement = "", x = text1)

# [0-9]: 0 ~ 9 숫자

# Q1. 영문 대문자 치환
gsub(pattern = "[A-Z]", replacement = "@", x = text1)

# Q2. 한글 치환
gsub(pattern = "[ㄱ-ㅎ]", replacement = "@", x = text1)
gsub(pattern = "[ㅏ-ㅣ]", replacement = "@", x = text1)
gsub(pattern = "[가-힣]", replacement = "@", x = text1)
gsub(pattern = "[ㄱ-힣]", replacement = "@", x = text1)

# Q3. 특수문자 치환
gsub(pattern = ".", replacement = "@", x = text1)
gsub(pattern = "\\.", replacement = "@", x = text1)

list.files(pattern = "\\.csv$")

gsub(pattern = "[[:punct:]]", replacement = "@", x = text1)

gsub(pattern = "1234|asdf", replacement = "@", x = text1)
gsub(pattern = "123|asd|가나다라", replacement = "@", x = text1)

# 정규표현식(regular expression)에서의 괄호 사용법
# (): 2개 이상의 표현식을 묶을때
# {}: 특정 패턴의 반복을 명시할 때
# []: 주로 범위 지정에 사용

gsub(pattern = "[0-3]", replacement = "@", x = text1)
gsub(pattern = "[2-3]", replacement = "@", x = text1)

# 숫자가 두 번 반복
gsub(pattern = "[0-9]{2}", replacement = "@", x = text1)

gsub(pattern = "[[:alpha:]]{2}", replacement = "@", x = text1)
gsub(pattern = "[A-z]{2}", replacement = "@", x = text1)
gsub(pattern = "[A-z]", replacement = "@", 
     x = "asdf ()^` 3rwefw34y")

gsub(pattern = "[a-zA-Z]", replacement = "@", x = text1)
gsub(pattern = "[a-z,A-Z]", replacement = "@", 
     x = "asdf , asdf , w23r")

list.files()

df = read.csv("news_ecommerce_lda_k10.csv")
head(df, 2)

# TV로 끝나는 이름을 가지는 언론사 데이터만 추출
df_sub = df[grep(pattern = "TV$", df$press), ]
head(df_sub)
unique(df_sub$press)

# 중국 으로 시작하는 제목을 가진 데이터만 추출
df_sub = df[grep(pattern = "^중국", df$title), ]
head(df_sub)

text2
gsub(pattern = "<.*?>", replacement = "@", text2)
# .*?: 0개 이상의 모든 문자열

gsub(pattern = "\\([가-힣]*?\\)", replacement = "@", 
     "데이터분석(데분)")
# 소괄호의 경우 별도의 정규식 문법이 있기 때문에
# 역슬래시 2개를 앞에 붙여줘야 함.


# https://search.naver.com/search.naver?query=%EB%B9%85%EB%8D%B0%EC%9D%B4%ED%84%B0&where=news&ie=utf8&sm=nws_hty
url = "https://search.naver.com/search.naver?query=%EB%B9%85%EB%8D%B0%EC%9D%B4%ED%84%B0&where=news&ie=utf8&sm=nws_hty"
library("rvest")
text = read_html(url, encoding = "UTF-8")
text

text %>% 
  html_children() %>%  
  html_children()

# CSS Selector, Xpath

# //*[@id="sp_nws1"]/div[1]/div/a

# %>%: 파이프 연산자. 직전의 연산결과를 다음 함수 입력으로 전달.
# [Ctrl] + [Shift] + [M]
text %>% 
  html_nodes(xpath = '//*[@id="sp_nws1"]/div[1]/div/a')

text %>% 
  html_nodes(xpath = '//*[@id="sp_nws1"]/div[1]/div/a') %>%  
  html_text()

# //* : 위치 무관 모든 태그
# [@id="sp_nws1"] : 특정 태그의 id 에 'sp_nws1' 값이 할당되어 있는 것
# div[1] : div 태그가 여러개 있는 경우 첫 번째 div 태그 선택

text %>% 
  html_nodes(xpath = '//ul[@class="list_news"]')

text %>% 
  html_nodes(xpath = '//ul[@class="list_news"]') %>%  
  html_nodes(xpath = '//div[@class="news_area"]/a')

text %>% 
  html_nodes(xpath = '//ul[@class="list_news"]') %>%  
  html_nodes(xpath = '//div[@class="news_area"]/a') %>% 
  as.character()

text %>% 
  html_nodes(xpath = '//ul[@class="list_news"]') %>%  
  html_nodes(xpath = '//div[@class="news_area"]/a') -> ls_news

ls_news %>%  
  html_attr("href") -> news_link

ls_news %>%  
  html_text() -> news_title

# //*[@id="sp_nws1"]/div[1]/div/div[1]/div/a[1]
# class="info press"

text %>% 
  html_nodes(xpath = '//ul[@class="list_news"]') %>%  
  html_nodes(xpath = '//div[@class="news_area"]') %>% 
  html_nodes(xpath = '//a[@class="info press"]') %>%  
  html_text()

text %>% 
  html_nodes(xpath = '//a[@class="info press"]') %>%  
  html_text() -> news_press


text %>% 
  html_nodes(xpath = '//ul[@class="list_news"]') %>%  
  html_nodes(xpath = '//div[@class="news_area"]') %>%  
  html_nodes(xpath = '//span[@class="info"]') %>%  
  html_text() %>% 
  grep(pattern = "(전|\\.)$", value = TRUE) -> news_time

ls()
ls(pattern = "^news")
df_news = data.frame(time  = news_time,
                     press = news_press,
                     link  = news_link,
                     title = news_title)
head(df_news)

# https://search.naver.com/search.naver?
# &where=news
# &query=%EB%B9%85%EB%8D%B0%EC%9D%B4%ED%84%B0
# &sm=tab_pge
# &sort=0
# &photo=0
# &field=0
# &reporter_article=
# &pd=0&ds=&de=&docid=&nso=so:r,p:all,a:all
# &mynews=0&cluster_rank=38
# &start=11&refresh_start=0

# all&mynews=0&cluster_rank=67&start=51&refresh_start=0

url = glue("https://search.naver.com/search.naver?&where=news&query=%EB%B9%85%EB%8D%B0%EC%9D%B4%ED%84%B0&sm=tab_pge&sort=0&photo=0&field=0&reporter_article=&pd=0&ds=&de=&docid=&nso=so:r,p:all,a:all&mynews=0&start={start}&refresh_start=0",
           start = 1)

df_news = data.frame()
for(start in c(1, 11, 21)){
  # 크롤링 하는 코드
  df_news = rbind(df_news, df_news_sub)
  Sys.sleep(2 + runif(1))
}
head(df_news)
nrow(df_news)


df_news = data.frame()
for(start in c(1, 11, 21)){
  url = glue("https://search.naver.com/search.naver?&where=news&query=%EB%B9%85%EB%8D%B0%EC%9D%B4%ED%84%B0&sm=tab_pge&sort=0&photo=0&field=0&reporter_article=&pd=0&ds=&de=&docid=&nso=so:r,p:all,a:all&mynews=0&start={start}&refresh_start=0",
             start = start)
  text = read_html(url, encoding = "UTF-8")
  text %>% 
    html_nodes(xpath = '//ul[@class="list_news"]') %>%  
    html_nodes(xpath = '//div[@class="news_area"]/a') -> ls_news
  ls_news %>%  
    html_attr("href") -> news_link
  ls_news %>%  
    html_text() -> news_title
  text %>% 
    html_nodes(xpath = '//a[@class="info press"]') %>%  
    html_text() -> news_press
  text %>% 
    html_nodes(xpath = '//ul[@class="list_news"]') %>%  
    html_nodes(xpath = '//div[@class="news_area"]') %>%  
    html_nodes(xpath = '//span[@class="info"]') %>%  
    html_text() %>%
    grep(pattern = "(전|\\.)$", value = TRUE) -> news_time
  df_news_sub = data.frame(time  = news_time,
                           press = news_press,
                           link  = news_link,
                           title = news_title)
  
  df_news = rbind(df_news, df_news_sub)
  Sys.sleep(2 + runif(1))
}
head(df_news)
nrow(df_news)

text = read_html("http://www.fntoday.co.kr/news/articleView.html?idxno=252616",
                 encoding = "UTF-8")
text %>% 
  html_nodes(xpath = '//div[@itemprop="articleBody"]') %>%  
  html_text()

text %>% 
  html_nodes(xpath = '//div[@itemprop="articleBody"]') %>%  
  html_children() %>%  
  html_text() -> text_main

grep(pattern = "^저작권", text_main)
grep(pattern = "^저작권", text_main, value = TRUE)

text %>% 
  html_nodes(xpath = '//div[@itemprop="articleBody"]') %>%  
  html_children() %>%  
  html_text() %>%  
  .[1:(grep(pattern = "^저작권", x = .) - 1)] -> text_main

paste(text_main, collapse = "@@")


URLencode("빅데이터")
URLencode(enc2utf8("빅데이터"))

list_keyword = c("빅데이터", "교육", "선거")
for(keyword in list_keyword){
  print(glue("aaa.com?query={keyword}&page={page}",
             keyword = keyword,
             page = sprintf(fmt = "%02d", 2)))
}


# 쿠팡!
# https://www.coupang.com/np/categories/194320
library("rvest")
text = read_html("http://browse.gmarket.co.kr/list?category=200000482",
                 encoding = "UTF-8")
text %>% 
  html_nodes(xpath = '//*[@id="section__inner-content-body-container"]') %>%  
  html_children() %>%  
  html_text()

text %>% 
  html_nodes(xpath = '//*[@id="section__inner-content-body-container"]') %>%  
  html_nodes(xpath = '//div[@class="box__item-container"]/div[2]') -> ls_prod
  
ls_prod %>%  
  html_nodes(xpath = '//div[@class="box__information-major"]') %>% 
  html_children() %>%  
  html_text()
  
ls_prod %>%  
  html_nodes(xpath = '//div[@class="box__information-major"]') %>% 
  html_children() %>%  
  html_text() %>% 
  grep(pattern = "^(상품명|상품금액)", value = TRUE) -> prod_main
prod_main

matrix(prod_main, ncol = 2, byrow = TRUE)


df = read.csv("news_ecommerce_lda_k10.csv")
head(df, 2)

strsplit(df[1, "title"], split = " ")
strsplit(df[1:3, "title"], split = " ")
unlist(strsplit(df[1:3, "title"], split = " "))

df_word = as.data.frame(table(unlist(strsplit(df$title, split = " "))))
head(df_word)

df_word = df_word[order(df_word$Freq, decreasing = TRUE), ]
head(df_word)

nchar(df_word$Var1)
class(df_word$Var1)

df_word[, "Var1"] = as.character(df_word$Var1)
nchar(df_word$Var1) # 글자 개수.

# Q. 두 글자 이상의 한글만 들어가있는 row를 필터링하여
#    df_word_sub 에 저장하시오.
df_word_sub = df_word[grep(pattern = "[ㄱ-힣]{2}", df_word$Var1), ]
df_word_sub = df_word[grep(pattern = "[ㄱ-힣]{2,}",  # 2개 이상
                           df_word$Var1), ]
head(df_word_sub)
nrow(df_word)
nrow(df_word_sub)

df_word_100 = df_word_sub[1:100,]
head(df_word_100)


# install.packages("wordcloud2")
library("wordcloud2")
wordcloud2(df_word_100)




# install.packages("ggwordcloud")
library("ggwordcloud")
ggplot(data = df_word_100,
       aes(label = Var1)) + 
  geom_text_wordcloud()

vec_word = unlist(strsplit(df$title, split = " "))
ggplot() + 
  geom_text_wordcloud(aes(label = vec_word[1:100]))


set.seed(42)
ggplot(love_words_small, aes(label = word)) +
  geom_text_wordcloud() +
  theme_minimal()


# install.packages("excel.link")
library("excel.link")
xlrc[["a1"]] = 1:10

xl.sheet.add("new")
xlrc[["b2"]] = 1:10
xl.sheet.add("new2")
xlrc[["b2"]] = iris





