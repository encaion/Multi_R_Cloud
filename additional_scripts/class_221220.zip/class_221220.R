iris[, "Sepal.Length"]
iris[, c("Sepal.Length", "Petal.Length")]
head(iris, 2)
tail(iris, 2)
colnames(iris)
nrow(iris) # number of rows
ncol(iris) # number of columns

getwd()
list.files()

df_r = read.csv("rating_ramyun.csv")
head(df_r)
tail(df_r, 2)
nrow(df_r)
ncol(df_r)
colnames(df_r)
df_r$Top_Ten
df_r$Top_Ten[1]
df_r[1, "Top_Ten"]

table(df_r$Top_Ten)

df_r[1, "Top_Ten"] == "" 

df_r_sub = df_r[df_r$Top_Ten != "", ]
head(df_r_sub)

unique(df_r_sub$Top_Ten) # 고유원소(중복 제거)
df_r_sub = df_r_sub[df_r_sub$Top_Ten != "\n", ]
unique(df_r_sub$Top_Ten)

nrow(df_r_sub)
head(df_r_sub, 2)

vec = letters[1:6]
vec[vec == "c"]
vec[vec != "c"]
vec[(vec == "c") | (vec == "f")] # A조건 또는 B조건
vec[vec %in% c("c", "f")]
?`%in%`
vec[!(vec %in% c("c", "f"))]

FALSE
!FALSE

`+`(2, 5)

df_r_sub = df_r_sub[!(df_r_sub$Top_Ten %in% c("", "\n")), ]
unique(df_r_sub$Top_Ten)

ls() # 만들어진 객체 목록(list)
rm("vec") # vec 객체 삭제
gc() # 메모리 정리.

head(df_r_sub, 2)
df_r_sub2 = df_r_sub[, c(1, 7)]
head(df_r_sub2, 2)

colnames(df_r_sub)
t(t(colnames(df_r_sub))) # 행렬전치 함수의 활용

df_r_sub2[, "year1"] = substr(df_r_sub2$Top_Ten, 
                              start = 1, stop = 4)
head(df_r_sub2)
class(df_r_sub2$year1)
df_r_sub2[, "year1"] = as.numeric(df_r_sub2$year1)
class(df_r_sub2$year1)
unique(df_r_sub2$Top_Ten)

library("splitstackshape") # split, stack, shape
df_r_s = cSplit(df_r_sub2, splitCols = "Top_Ten", 
                sep = " #")
head(df_r_s)

df_r_s = as.data.frame(df_r_s)
colnames(df_r_s)[c(3, 4)] = c("top_year", "top_rank")
head(df_r_s, 2)

df_r_sub_bind = cbind(df_r_sub, df_r_s[, 3:4])
head(df_r_sub_bind, 2)

head(df_r_s[, -1], 3)
head(df_r_s[, c(-1, -3)], 3)

aws = read.csv("AWS_sample.txt", sep = "#")
head(aws, 2)

aws[, 6] = "new"
head(aws, 2)
aws[, "col_new"] = 123
head(aws, 2)
aws[, "col_new"] = 999
head(aws, 2)


for(n in 1:3){
  print(n)
}

for(n in c(2, 5, 7)){
  print(n)
}

dir.create("data")
for(n_row in 1:10){
  # n_row = 1
  df_sub = iris[n_row:(n_row + 3), ]
  file_name_sub = paste0("data/iris_sub_",
                         sprintf("%02d", n_row),
                         ".csv")
  write.csv(df_sub, file_name_sub, row.names = FALSE)
}

file_list = list.files(path = "data",
                       full.names = TRUE)
file_list # 하위폴더 data에 있는 파일들의 전체 경로

read.csv(file_list[1], nrows = 2)
file_list[1]

for(file_path in file_list){
  print(file_path)
}

for(n_path in 1:length(file_list)){
  print(file_list[n_path])
}

df_bind = data.frame()
for(file_path in file_list){
  print(file_path)
  df_bind_sub = read.csv(file_path)
  df_bind = rbind(df_bind, df_bind_sub)
  print(nrow(df_bind))
  Sys.sleep(2) # 2초간 잠시 멈춤
}

n = 100
n > 40

if(n > 40){
  print("yes")
}

if(n < 40){
  print("yes")
} else {
  print("no")
}

list.files()
bike = read.csv("bike.csv")
head(bike, 2)

# Q1. temp의 평균은?
mean(bike$temp)

# Q2. "season"이 3인 row를 추출하고 bike_sub 객체에 저장하시오.
#     그리고 bike_sub객체의 "atemp" 변수의 평균을 산출하시오.
bike_sub = bike[bike$season == 3, ]
mean(bike_sub$atemp)

# Q3. "season"이 2 이면서 "weather"가 2인 데이터를 필터링 하여
#     bike_s2_w2 객체에 저장하고 행(row) 개수를 확인하시오.
bike_s2_w2 = bike[(bike$season == 2) & (bike$weather == 2), ]
nrow(bike_s2_w2)

sum((bike$season == 2) & (bike$weather == 2))

# Q4. "temp" 변수의 평균값 보다 큰 데이터를 필터링 하여
#     bike_GT_temp_m 객체에 저장하고 해당 객체의
#     "humidity" 변수의 평균을 계산하시오.
bike_GT_temp_m = bike[bike$temp > mean(bike$temp), ]
mean(bike_GT_temp_m$humidity)

table(bike$season, bike$weather)
table(bike[, c("season", "weather")])

str(bike)

vec = LETTERS
vec
vec[17]

summary(bike)

library("psych")
describe(bike)

# install.packages("DataExplorer")
library("DataExplorer")
create_report(bike)

df = airquality
quantile(df$Wind, probs = 0.99) # 제 99백분위수
quantile(df$Wind, probs = c(0.05, 0.95))

aggregate(data = df, Wind ~ Month, FUN = "mean")
# SELECT AVG(Wind) AS Wind, Month FROM df GROUP BY Month
head(df)


vec2 = c("a", "a", "a", "b", "b")
ifelse(test = vec2 == "a", yes = "A!", no = "B!")
ifelse(vec2 == "a", 1, 0)
(vec2 == "a") + 0
(vec2 == "a") * 1
as.numeric(vec2 == "a")

ifelse(vec2 == "a", 1, vec2)

# df[, 3] = ifelse(df[, 3] > 3, 1, 2)

df = read.csv("rating_ramyun.csv")
head(df, 2)

df[, "kr"] = ifelse(df$Country == "South Korea", 1, 0)
head(df)

# Q. "Stars" 변수의 값이 "Unrated"인 행을 제거하고
#    "Stars" 변수를 숫자로 바꾼 후 다음의 코드를 실행하시오.
df = df[df$Stars != "Unrated", ]
# df$Stars = as.numeric(df$Stars)
df[, "Stars"] = as.numeric(df$Stars)
df_agg = aggregate(data = df,
                   Stars ~ Country + Style, 
                   FUN = "mean")
df_agg

df = iris[1:4, -5]
df

apply(X = df, MARGIN = 1, FUN = "sum")
apply(X = df, MARGIN = 2, FUN = "sum")

apply(X = df, MARGIN = 2, FUN = "mean")

round_mean = function(x, d = 3){
  return(round(mean(x), digits = d))
}
round_mean(c(100, 77, 129, 333, 54.321))
round_mean(c(100, 77, 129, 333, 54.321), d = 1)

apply(X = df, MARGIN = 2, FUN = "round_mean")
apply(X = df, MARGIN = 2, FUN = "round_mean", d = 1)
?mean

list.files(pattern = "score")

score = read.csv("class_score.csv")
head(score)
# apply(X = score, MARGIN = 2, FUN = "mean")

apply(X = score[, 5:9], MARGIN = 2, FUN = "mean")
apply(X = score[, 5:9], MARGIN = 2, FUN = "min")

score_sub = score[, 5:9]
stat_mean = apply(X = score_sub, 2, FUN = "mean")
stat_max  = apply(X = score_sub, 2, FUN = "max")
stat_min  = apply(X = score_sub, 2, FUN = "min")

df_subject = data.frame(subject = colnames(score_sub),
                        mean = stat_mean,
                        max  = stat_max,
                        min  = stat_min)
rownames(df_subject) = NULL
df_subject


df_p = data.frame(xx = 1:10,
                  yy = c(3:1, 2:6, 9:10))
library("ggplot2")
ggplot(data = df_p, mapping = aes(x = xx, y = yy)) + 
  geom_point()

ggplot(data = df_p, aes(x = xx, y = yy)) + geom_line()
ggplot(data = df_p, aes(x = xx, y = yy)) + geom_col()

ggplot() + geom_point(data = df_p, aes(x = xx, y = yy))

ggplot(data = df_p, aes(x = xx, y = yy)) +
  geom_line() + 
  geom_point()

ggplot() +
  geom_line(data = df_p, aes(x = xx, y = yy)) + 
  geom_point(data = df_p, aes(x = xx, y = yy))

ggplot(data = df_p, aes(x = xx, y = yy)) +
  geom_line(linewidth = 2) + 
  geom_point(size = 5, color = "#FFAACC")

ggplot(data = df_p, aes(x = xx, y = yy)) +
  geom_point(size = 5, color = "#FFAACC") + 
  geom_line(linewidth = 2)
  
ggplot(data = df_p, 
       aes(x = xx, y = yy, fill = yy)) + 
  geom_col()

ggplot(data = df_p, 
       aes(x = xx, y = yy)) + 
  geom_col(fill = "red")

ggplot(data = df_p, 
       aes(x = xx, y = yy)) + 
  geom_col(color = "red")

dia = as.data.frame(diamonds)
head(dia, 2)
dia_agg = aggregate(data = dia, price ~ cut, FUN = "mean")
head(dia_agg)
ggplot(data = dia_agg, 
       aes(x = cut, y = price, fill = cut)) + 
  geom_col()

ggplot(data = dia_agg, 
       aes(x = cut, y = price, fill = cut)) + 
  geom_col() + 
  theme(legend.position = "none")

ggplot(data = dia_agg, 
       aes(x = cut, y = price, fill = cut)) + 
  geom_col() + 
  coord_flip() +
  theme(legend.position = "none")

ggplot(data = dia_agg, 
       aes(x = cut, y = price, fill = cut)) + 
  geom_col() + 
  coord_flip() +
  theme_bw() +
  theme(legend.position = "none")


ggplot(data = dia_agg, 
       aes(x = cut, y = price, fill = cut)) + 
  geom_col(width = 0.6) + 
  coord_flip() +
  theme_bw() +
  theme(legend.position = "none",
        panel.grid.minor = element_blank(),
        panel.grid.major.y = element_blank(),
        panel.grid.major.x = element_line(size = 1.2))

ggplot(data = dia_agg, 
       aes(x = cut, y = price, fill = cut)) + 
  geom_col(width = 0.6) + 
  geom_text(aes(label = round(price), y = price * 0.88)) +
  geom_text(aes(label = round(price), y = price * 0.88 - 40),
            color = "#FFFFFF") +
  coord_flip() +
  theme_bw() +
  theme(legend.position = "none",
        panel.grid.minor = element_blank(),
        panel.grid.major.y = element_blank(),
        panel.grid.major.x = element_line(size = 1.2))

gg = ggplot(data = dia_agg, 
            aes(x = cut, y = price, fill = cut)) + 
  geom_col(width = 0.6) + 
  geom_text(aes(label = round(price), y = price * 0.88)) +
  geom_text(aes(label = round(price), y = price * 0.88 - 40),
            color = "#FFFFFF") +
  coord_flip() +
  theme_bw() +
  theme(legend.position = "none",
        panel.grid.minor = element_blank(),
        panel.grid.major.y = element_blank(),
        panel.grid.major.x = element_line(size = 1.2))
gg

ggsave("ggplot_sample.pdf", plot = gg, 
       width = 7, height = 6)

gg + 
  labs(title = "title", subtitle = "subtitle",
       x = "Cut", y = "Price($)", 
       caption = "R Class")
