library("ggplot2")
dia = as.data.frame(diamonds)
head(dia, 2)

# Q1. "cut" 변수가 "Fair"이면서 "clarity"가 "I1"인
#     데이터를 추출하여 dia_sub 객체에 저장하고
#     해당 객체의 행 개수를 확인하시오.
dia_sub = dia[(dia$cut == "Fair") & (dia$clarity == "I1"), ]
nrow(dia_sub)

sum((dia$cut == "Fair") & (dia$clarity == "I1"))

# Q2. 세공수준(cut)별 가격(price)의 최대값을 계산하시오.
#  ※  색상이 "G" 또는 "D"인 다이아몬드를 대상으로 분석하시오.
library("ggplot2")
dia = as.data.frame(diamonds)
head(dia, 2)

dia_sub = dia[dia$color %in% c("G", "D"), ]
aggregate(data = dia_sub, price ~ cut, FUN = "max")


list.files()
aws = read.csv("AWS_sample.txt", sep = "#")
head(aws, 2)

# Q. AWS 장비번호 108을 기준으로 기록된 데이터에서
#    열대야인 날이 며칠인지 확인하려고 한다....
unique(aws$AWS_ID)
table(aws$AWS_ID)

aws_108 = aws[aws$AWS_ID == 108, ]
unique(aws_108$AWS_ID)
head(aws_108, 2)

library("lubridate")
aws_108[, "TM2"] = ymd_h(aws_108$TM)
head(aws_108)

aws_108 = aws_108[, c("TM2", "TA")]
aws_108[, "date"] = as_date(aws_108$TM2)
aws_108[, "hour"] = hour(aws_108$TM2)
head(aws_108)

aws_108_tn = aws_108[  aws_108$hour %in% c(0:8, 18:23),]
aws_108_tn = aws_108[!(aws_108$hour %in%   9:17),]
nrow(aws_108_tn)

aws_108_tn_min = aggregate(data = aws_108_tn,
                           TA ~ date, FUN = "min")
head(aws_108_tn_min, 2)

aws_108_tn_min[, "tn"] = ifelse(aws_108_tn_min$TA >= 25, 1, 0)
aws_108_tn_min[50:60, ]


score = read.csv("class_score.csv")
head(score, 2)

sapply(score[, 5:9], FUN = "mean")
colMeans(score[, 5:9])

score[, "score_mean"] = apply(X = score[, 5:9], 1, FUN = "mean")
score[, "score_max" ] = apply(X = score[, 5:9], 1, FUN = "max")
head(score, 2)

# write.csv(aws_108_tn_min, "AWS_join.csv", row.names = FALSE)


aws = read.csv("AWS_sample.txt", sep = "#")
aws_108 = aws[aws$AWS_ID == 108, ]
head(aws_108, 2)

aws_join = read.csv("AWS_join.csv")
head(aws_join, 2)
library("dplyr")

aws_108[, "date"] = as_date(ymd_h(aws_108$TM))
head(aws_108, 2)
aws_108_join = left_join(aws_108, aws_join,
                         by = c("date" = "date"))
aws_join[, "date"] = as_date(aws_join$date)
aws_108_join = left_join(aws_108, aws_join,
                         by = c("date" = "date"))
head(aws_108_join)

aws_108_join = left_join(aws_108, aws_join[, -2],
                         by = c("date" = "date"))
head(aws_108_join)

time = Sys.time()
1 + 1
Sys.time() - time

seq(from = as_date("2022-12-01"), to = as_date("2022-12-31"),
    by = "2 days")

seq(from = as_date("2022-02-01"), to = as_date("2023-01-01"),
    by = "month") - 1 # 매월 말일.

strptime("2022년 12월 21일", format = "%Y년 %m월 %d일")
as_date("2022년 12월 21일")
as_date("2022@ 12@ 21@", format = "%Y@ %m@ %d@")
# %Y: 4자리 연도, %m: 월, %d: 일

as_date(12345, origin = "2020-01-01")
as_date(12345, origin = "1970-01-01") # !
as_date(12345, origin = "1900-01-01")

months("2022-12-21")
month("2022-12-21")

date_sample = as_date("2022-12-21")
date_sample

year(date_sample) = 2020
date_sample

library("data.table")
bike = fread("bike.csv", select = c("datetime", "count"),
             data.table = FALSE)
head(bike, 2)
# Q. "datetime" 변수를 참고하여 주말여부 변수 "is_wend"를 생성하고
#    주말의 "count" 변수 평균값을 산출하시오.
bike[, "wday"] = wday(bike$datetime)
bike[, "is_wend"] = ifelse(bike$wday %in% c(1, 7), 1, 0)
# head(bike, 2)
mean(bike[bike$is_wend == 1, "count"])

lubridate::wday("2022-12-19", week_start = 1, )
wday("2022-12-18")
wday("2022-12-17")


elec = read.csv("elec_load.csv")
head(elec, 2)

library("reshape2")
elec_melt1 = melt(elec, id.vars = c("YEAR", "MONTH", "DAY"))
head(elec_melt1)

elec_melt2 = melt(elec, id.vars = c("YEAR", "MONTH", "DAY"),
                  variable.name = "HOUR", value.name = "LOAD")
elec_melt2 = elec_melt2[order(elec_melt2$YEAR, 
                              elec_melt2$MONTH,
                              elec_melt2$DAY,
                              elec_melt2$HOUR), ]
head(elec_melt2)

elec_melt2[, "h1"] = gsub(pattern = "HR", replacement = "", 
                          elec_melt2$HOUR)
elec_melt2[, "h2"] = gsub(pattern = "X|HR", replacement = "", 
                          elec_melt2$HOUR)
elec_melt2[, "h3"] = gsub(pattern = "[^0-9]", replacement = "", 
                          elec_melt2$HOUR)
head(elec_melt2)

elec_melt2[, "date"] = as_date(paste(elec_melt2$YEAR,
                                     elec_melt2$MONTH,
                                     elec_melt2$DAY, sep = "-"))
elec_melt2[, "dt"] = ymd_h(paste(elec_melt2$date,
                                 elec_melt2$h3))
head(elec_melt2)

library("ggplot2")
ggplot(data = elec_melt2,
       aes(x = dt, y = LOAD, color = LOAD)) + 
  geom_hline(yintercept = 60000, linewidth = 1.2,
             color = "#FF0000") + 
  geom_line() + 
  theme_bw() +
  theme(legend.position = "none")

ggplot(data = elec_melt2[75000:85104, ],
       aes(x = dt, y = LOAD, color = LOAD)) + 
  geom_hline(yintercept = 60000, linewidth = 1.2,
             color = "#FF0000") + 
  geom_line() + 
  scale_x_datetime(date_breaks = "3 months",
                   date_labels = "%Y-%m") +
  theme_bw() +
  theme(legend.position = "none")





