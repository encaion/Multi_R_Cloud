123

# 1. 시작하기 ####
# 2. 단축키 ####

#### 주석 ####
# comment
1 + 1 # 더하기 ㅋㅋㅋ

# 1 + 2 + 3 음?
# [Ctrl] + [Shift] + [c]


# install.packages("beepr")
library("beepr")
beep(2)

beepr::beep(2)

library("data.table")

aaa = function(){}
aaa()

ccc = function(x){
  x
}

ccc()
ccc(123)

list.files()
source("new_fun_src.R")

getwd()
# get working directory address
?getwd

list.files()

head(iris)

TRUE
FALSE
TRUE + FALSE
FALSE + FALSE
sum(c(TRUE, TRUE, FALSE))
T + F

'a'
"a"
123
NA

c(1, 2)
c("a", "b")
c(1, 2, "a")
aa = c(100, 200)
aa
aa[2] = "kk"
aa

data.frame(v1 = 1:3,
           v2 = 4:6)
data.frame(xx = c(1, 2, 3),
           yy = c(100, 200))
df = data.frame(col1 = c("a", "b", "c", "d"),
                col2 = 2:5)
df
df$col1
df[, "col1"]
df[1, ]
# df[ row , column ]

library("imager")
img = load.image("sample_cat_image.jpg")
plot(img)

img[1:3, 1:3, 1, 1]

img[,,, 1] = 1 - img[,,, 1]
img[,,, 2] = 1 - img[,,, 2]
img[,,, 3] = 1 - img[,,, 3]
plot(img)

library("rvest")
url = "https://search.naver.com/search.naver?where=news&ie=utf8&sm=nws_hty&query=%EC%9B%94%EB%93%9C%EC%BB%B5"
text = read_html(url, encoding = "UTF-8")
text %>% 
  html_elements(css = ".news_area a.news_tit") %>% 
  html_text() -> news_title
news_title

vec1 = c("123$", "456$")
as.numeric(vec1)
as.numeric(gsub("\\$", "", vec1))
as.numeric(gsub(pattern = "\\$", replacement = "", vec1))

df = read.csv("rating_chocobar.csv")
df_tbl = table(df$Cocoa_Percent)
df_tbl = as.data.frame(df_tbl)
df_tbl

head(df_tbl)
tail(df_tbl)

head(df_tbl, 3)
head(df_tbl, 20)
?head

# install.packages("data.table")
library("data.table")
df1 = fread("class_score.csv")
head(df1, 2)
class(df1)

library("readr")
df2 = read_csv("class_score.csv")
head(df2, 2)
class(df2)

df2 = as.data.frame(df2)
head(df2, 2)
class(df2)

"감자" == "고구마"
"감자" != "고구마"

"감자" == c("감자", "고구마", "사과")

vec2 = c("감자", "고구마", "사과")
vec2[vec2 == "감자"]
vec2[vec2 != "감자"]

seq(1, 3)
seq(1, 3, 1)
seq(from = 1, to = 3, by = 1)
seq(3, 1, 1)
seq(3, 1, -1)


# aws = read.delim("AWS_sample.txt")
# head(aws)
# aws = read.delim("AWS_sample.txt", sep = "#")
# head(aws)

aws = read.csv("AWS_sample.txt", sep = "#")
head(aws)

library("readxl")
xl_iris = read_excel("iris_xlsx.xlsx")
head(xl_iris)

excel_sheets("iris_xlsx.xlsx")

excel_sheets("excel_sample.xlsx")

ls_sheets = excel_sheets("excel_sample.xlsx")

df_bind = data.frame()
for(n in 1:length(ls_sheets)){
  df_bind = rbind(df_bind, 
                  read_excel("excel_sample.xlsx",
                             ls_sheets[n]))
}
df_bind

write.csv(iris, "iris_true.csv", row.names = TRUE)
write.csv(iris, "iris_false.csv", row.names = FALSE)

df4 = read.csv("iris_true.csv")
head(df4)

library("ggplot2")

# https://stackoverflow.com/questions/54428718/barplot-ggplot-with-different-background-color-per-bar-couple
library(tidyverse)
library(wrapr)

Mat <- matrix(c(1.97, 0.61, 0.06, 0.06, 0.61, 0.51, 0.03, 0.25, 2.25, 1.36, 0.15, 0.17, 1.19, 1.41, 0.04, 0.25),ncol=4,byrow=TRUE)
rownames(Mat) <- c("Cognitive Strategies","Motivational Strategies","SE Cognitive Strategies","SE Motivational Strategies")
colnames(Mat) <- c("No Problems","Motivational Problems","Knowledge Problems","Both Problems")
Mat <- as.data.frame(Mat)

Mat_long <-
  Mat %>%
  as_tibble() %>%
  mutate(
    Group = c('No Problems','Motivational Problems','Knowledge Problems','Both Problems'),
    xpos = row_number()
  ) %>%
  unite('Cognitive Strategies', c('Cognitive Strategies', 'SE Cognitive Strategies')) %>%
  unite('Motivational Strategies', c('Motivational Strategies', 'SE Motivational Strategies')) %>%
  gather(Type, val, `Motivational Strategies`:`Cognitive Strategies`) %>%
  separate(val, c('val', 'SE'), sep = '_') %>%
  mutate_at(4:5, as.numeric)

library("ggplot2")
plot(1, 1)
qplot(1, 1)
