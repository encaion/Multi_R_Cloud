# install.packages("wordcloud2")
library("wordcloud2")
df_cnt = data.frame(word = c("R", "Cloud", "Class"),
                    count = c(30, 50, 100))
wordcloud2(df_cnt, size = 0.5)


# 오늘 테슬라(TSLA, 8.8%)주가는 난리가 났습니다.
# 처리1 -> 오늘, 테슬라, TSLA, 주가 
# 처리2 -> 오늘, 테슬라, 주가
# 처리3 -> 테슬라, 주가

# install.packages('remotes')
# remotes::install_github("nathan-russell/hashmap")
install.packages("hashmap_0.2.1.tar.gz", repos = NULL, type = "source")
remotes::install_github('haven-jeon/KoSpacing')
# install.packages("KoNLP")
# library("KoNLP")


text = readLines("news_cold.txt")
head(text)

text_sub = text[text != ""]
text_sub = tolower(text_sub)
text_sub = text_sub[text_sub != "advertisement"]

grep(pattern = "@", text_sub)
grep(pattern = "@", text_sub, value = TRUE)
grepl(pattern = "@", text_sub)
text_sub = text_sub[!grepl(pattern = "@", text_sub)]
text_sub = text_sub[-(2:4)]
text_sub

text_sub2 = text_sub
text_sub2 = gsub(pattern = "\\(.*?\\)", replacement = "", x = text_sub2)
text_sub2 = gsub(pattern = "^.*?기자 = ", replacement = "", x = text_sub2)
text_sub2 = gsub(pattern = "[[:punct:]]", replacement = "", x = text_sub2)
text_sub2 = gsub(pattern = "(했|이)다", replacement = "", x = text_sub2)
text_sub2 = gsub(pattern = "(에|의|가|를|는|이) ", replacement = " ", x = text_sub2)
text_sub2

text_sub3 = text_sub2
text_sub3

text_sub3_split = strsplit(text_sub3, split = " ")
text_sub3_split = unlist(text_sub3_split)
text_sub3_split

word_cnt = table(text_sub3_split)
df_word_cnt = as.data.frame(word_cnt)
df_word_cnt = df_word_cnt[order(df_word_cnt$Freq, decreasing = TRUE), ]
df_word_cnt[, 1] = as.character(df_word_cnt[, 1]) # factor
df_word_cnt = df_word_cnt[nchar(df_word_cnt$text_sub3_split) > 1, ] # 1글자 초과
df_word_cnt = df_word_cnt[grep(pattern = "^[^0-9]", df_word_cnt[, 1]), ]
head(df_word_cnt)

# 특정 단어가 들어있는 row를 제외.
list_rm_words = c("된다", "등도", "등을", "따라")
df_word_cnt2 = df_word_cnt[!(df_word_cnt$text_sub3_split %in% list_rm_words), ]
# 임의의 데이터 추가(뻥튀기)
set.seed(123)
plus_cnt = sample(5:20, size = nrow(df_word_cnt2), replace = TRUE)
df_word_cnt2[, "Freq"] = df_word_cnt2$Freq + plus_cnt

library("wordcloud2")
wordcloud2(df_word_cnt2, size = 0.2)

# https://search.naver.com/search.naver?where=news&sm=tab_jum&query=%ED%95%9C%ED%8C%8C
URLencode("한파")
# https://search.naver.com/search.naver?where=news&sm=tab_pge&query=%ED%95%9C%ED%8C%8C
# &sort=0&photo=0&field=0&pd=0&ds=&de=&cluster_rank=27&mynews=0&office_type=0
# &office_section_code=0&news_office_checked=&nso=so:r,p:all,a:all&start=11

library("glue")
url_base = "https://search.naver.com/search.naver?where=news&sm=tab_pge"
url_param = glue("&query={search_word}&sort={sort}&ds={date_start}&de={date_end}&start={start}",
                 search_word = URLencode("한파"),
                 sort = 1,
                 date_start = "2022.12.01",
                 date_end = "2022.12.07",
                 start = 1)
url_param
url = paste0(url_base, url_param)
url

vec_search_words = c("한파", "자동차", "센서")
vec_start = seq(1, 50, by = 10)

for(n_word in vec_search_words){
  for(n_start in vec_start){
    url_param = glue("&query={search_word}&sort={sort}&ds={date_start}&de={date_end}&start={start}",
                     search_word = URLencode(n_word),
                     sort = 1,
                     date_start = "2022.12.01",
                     date_end = "2022.12.07",
                     start = n_start)
    print(paste0(url, url_param))
    Sys.sleep(2 + sample(1:10, size = 1) / 10)
  }
}

url_base = "https://search.naver.com/search.naver?where=news&sm=tab_pge"
url_param = glue("&query={search_word}&sm=tab_opt&sort=2&photo=0&field=0&pd=3&ds={date_start}&de={date_end}&start={start}",
                 search_word = URLencode("한파"),
                 date_start = "2022.12.01",
                 date_end = "2022.12.07",
                 start = 1)
url_param
url = paste0(url_base, url_param)
url

library("rvest")
text = read_html(url)
text

text %>% html_nodes(css = "ul.list_news > li") # CSS 선택자
text %>% html_nodes(xpath = "//ul[@class='list_news']/li") # xpath 문법

text %>% html_nodes(css = "ul.list_news > li") -> news_list
news_list[1]

news_list[1] %>% 
  html_nodes(css = "div.info_group > a") %>% 
  html_text() %>%  
  .[1] -> news_press # %>%  연산자 뒤에 사용하는 마침표는 직전 코드의 결과임.

library("lubridate")
news_list[1] %>% 
  html_nodes(css = "span.info") %>% 
  html_text() %>% 
  as_date() -> news_date # "1시간 전" 이런 것이 들어오면 에러남.

news_list[1] %>% 
  html_nodes(css = "a.news_tit") %>%  
  html_text() -> news_title
  
news_list[1] %>% 
  html_nodes(css = "a.news_tit") %>%  
  html_attr("href") -> news_link

df_news_sub = data.frame(date  = news_date,
                         press = news_press,
                         title = news_title,
                         link  = news_link)
df_news_sub

df_news_bind = data.frame()
for(n_news in 1:length(news_list)){
  # n_news = 4
  news_list[n_news] %>% 
    html_nodes(css = "div.info_group > a") %>% 
    html_text() %>%  
    .[1] -> news_press # %>%  연산자 뒤에 사용하는 마침표는 직전 코드의 결과임.
  
  news_list[n_news] %>% 
    html_nodes(css = "span.info") %>% 
    html_text() %>% 
    paste(collapse = "@") -> news_date
  
  news_list[n_news] %>% 
    html_nodes(css = "a.news_tit") %>%  
    html_text() -> news_title
  
  news_list[n_news] %>% 
    html_nodes(css = "a.news_tit") %>%  
    html_attr("href") -> news_link
  
  df_news_sub = data.frame(date  = news_date,
                           press = news_press,
                           title = news_title,
                           link  = news_link)
  df_news_bind = rbind(df_news_bind, df_news_sub)
}

df_news_bind[, "date"] = gsub(pattern = "^.*?@", replacement = "", df_news_bind$date)
df_news_bind[, "date"] = as_date(df_news_bind$date)
df_news_bind
