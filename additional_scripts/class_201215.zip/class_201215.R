aws = read.csv("AWS_sample.txt", sep = "#")
head(aws, 2)

test = readLines("AWS_sample.txt", n = 2) # 두 줄만 읽어옴.
test

aws[, "new_col"] = 1234
head(aws, 2)

aws[, ncol(aws) + 1] = aws$TA * aws$Wind
head(aws, 2)

colnames(aws)
colnames(aws)[7]
colnames(aws)[7] = "multi"
colnames(aws)

# Q. 네 번째, 다섯 번째 변수를 각각
#    v4, v5 로 변경하시오.
colnames(aws)[4]
colnames(aws)[5]
colnames(aws)[4:5] = c("v4", "v5")
colnames(aws)[c(4, 5)] = c("v4", "v5")

n = 3
if(n == 3){
  print("n 3 o")
} else {
  print("n 3 x")
}

if(n == 3){
  print("n 3 o")
}

df_1 = data.frame(aa = letters[1:4],
                  bb = 1:4)
df_1

df_1[df_1$bb >= 3, ]
which(df_1$bb >= 3)

head(aws, 2)
# Q1. AWS_ID가 108인 것을 추출하여 aws_108 객체에 저장하시오.
aws_108 = aws[aws$AWS_ID == 108, ]
# Q2. 기온이 25도 이상인 데이터를 추출하여 aws_ta25 객체에 저장하시오.
aws_ta25 = aws[aws$TA >= 25, ]
# Q3. 기온이 25도 이상이면서 풍속이 0인 데이터는 몇 건인가?
nrow(aws[(aws$TA >= 25) & (aws$Wind == 0), ])
sum((aws$TA >= 25) & (aws$Wind == 0))


dir.create("bike")
list.files()

bike = read.csv("bike.csv")

bike_sub = bike[bike$season == 3, ]

write.csv(bike_sub, "bike/bike_season_3.csv", row.names = FALSE)
bike_check = read.csv("bike/bike_season_3.csv")

paste0("bike/bike_season_", 3, ".csv")

# Q. bike객체에서 season별로 데이터를 분리하여 
#    각각의 파일을 bike폴더에 저장하시오.
# ※ 단, 반복문을 활용할 것.
str(bike)
summary(bike)
unique(bike$season) # 중복제거 및 고유값 확인
for(n in 1:4){
  print(n)
  bike_sub = bike[bike$season == n, ]
  print(head(bike_sub))
}
for(n in 1:4){
  bike_sub = bike[bike$season == n, ]
  # 파일을 저장하는 코드.
}

for(n in 1:4){
  bike_sub = bike[bike$season == n, ]
  print(paste0("bike/bike_season_", n, ".csv"))
}

for(n in 1:4){
  bike_sub = bike[bike$season == n, ]
  write.csv(bike_sub, paste0("bike/bike_season_", n, ".csv"),
            row.names = FALSE)
}
list.files(path = "bike/")

file_list = list.files(path = "bike/",
                       full.names = TRUE)
file_list

for(file_path in file_list){
  print(file_path)
}

bike_total = data.frame()
for(file_path in file_list){
  print(file_path)
}
# Q. bike 폴더에 계절별로 나뉘어진 파일을 각각 읽어와서
#    bike_total 객체에 합쳐서 넣어보시오.
# ※ rbind() 활용

bike_total = data.frame()
for(file_path in file_list){
  print(file_path)
}

bike_total = data.frame()
for(file_path in file_list){
  print(file_path)
  bike_sub = read.csv(file_path)
  bike_total = rbind(bike_total, bike_sub)
}

data("airquality")
df = airquality
df_sub = df[1:5, ]
df_sub

df[df$Day == 1, ]
df[df$Day != 1, ]
df[df$Day <= 2, ]
df[(df$Day == 1) & (df$Day == 2), ]
df[(df$Day == 1) | (df$Day == 2), ] # ★
df$Day %in% 1:2
df[df$Day %in% 1:2, ] # ★
df[!(df$Day %in% 1:2), ]
TRUE
FALSE
!TRUE
!c(TRUE, FALSE)

df[(df$Month == 6) & (df$Day %in% 1:2), ]
sum(df$Day %in% 1:2) # 1일, 2일 데이터가 몇 개 있는가?


install.packages("ggplot2")
data("diamonds", package = "ggplot2")
head(diamonds, 2)

table(diamonds$cut, diamonds$clarity)
table(diamonds$cut)
prop.table(table(diamonds$cut))
# Q. 위 코드의 결과를 백분률로 표기하시오.
#    그리고 반올림하여 소수점 둘 째 자리까지 표기하시오.
# paste0() - 선택
# round() - 필수

round(prop.table(table(diamonds$cut)) * 100, 2)
paste0(round(prop.table(table(diamonds$cut)) * 100, 2), "%")

paste0("a", "b", "c")
paste("a", "b", "c")
paste("a", "b", "c", sep = "-")

unique(df$Month)
length(c(1, 3, 5, 6, 6))
length(unique(df$Month))

# length(df)
# ncol(df)

# 데이터프레임은 리스트 객체의 특수한 형태
listt = list(a = 1:3,
             b = c("a", "b"),
             c = 4:7)
length(listt)

quantile(df$Wind)
quantile(df$Wind, probs = c(0.01, 0.99))

bike = read.csv("bike.csv")
head(bike, 2)

# Q1. 계절(season)별, 날씨(weather)별 기온의 최대값을
#     계산하여 df_agg_01 객체에 저장하시오.
df_agg_01 = "!?!?!?!?"
df_agg_01 = aggregate(data = bike, temp ~ season + weather,
                      FUN = "max")

# Q2. 계절(season)별, 휴일 여부(holiday)별 casual의 평균값을
#     계산하여 df_agg_02 객체에 저장하시오.
df_agg_02 = aggregate(data = bike, casual ~ season + holiday,
                      FUN = "mean")

df_agg_02[, "casual_r2"] = round(df_agg_02$casual, 2)
head(df_agg_02, 2)

1:4 >= 3
ifelse(test = 1:4 >= 3, yes = "up", no = "down")

c("a", "b", "c") == "c"
ifelse(test = c("a", "b", "c") == "c", yes = 1, no = 0)


df = read.csv("rating_ramyun.csv")
head(df, 2)
df[, "kr"] = ifelse(test = df$Country == "South Korea",
                    yes = 1, no = 0)
table(df[, c("Country", "kr")])

score = read.csv("class_score.csv")
head(score, 2)

score_min = apply(X = score[, -(1:4)], MARGIN = 2, FUN = "min")
score_max = apply(X = score[, -(1:4)], MARGIN = 2, FUN = "max")
score_avg = apply(X = score[, -(1:4)], MARGIN = 2, FUN = "mean")
df_subject = data.frame(min = score_min,
                        max = score_max,
                        avg = score_avg)
df_subject[, "subject"] = rownames(df_subject)
rownames(df_subject) = NULL # 초기화
df_subject = df_subject[, c(4, 1, 2, 3)]
df_subject

source("data_generator_join.R", encoding = "UTF-8")
head(df_room)
head(df_list)

# install.packages("dplyr", dependencies = TRUE, INSTALL_opts = '--no-lock')
library("dplyr")
df_join = left_join(x = df_list, y = df_room,
                    by = c("member" = "name"))
head(df_join)

Sys.Date()
Sys.time()
paste0("file_", gsub("-", "", Sys.Date()), ".csv")

time = Sys.time()
df = read.csv("bike.csv")
Sys.time() - time

bike = read.csv("bike.csv")
head(bike, 2)

strptime(x = "2020년 12월 15일",
         format = "%Y년 %m월 %d일")
as.Date(44000, origin = "1900-01-01")
as.Date(30000, origin = "1899-12-30")

# install.packages("lubridate")
library("lubridate")
ymd(20201215)
ymd("20201215")
ymd("201215")
ymd("20/12/15")

months(as.POSIXct("2020-12-15"))
month("2020-12-15")

head(bike, 2)
# Q1. 월별 casual의 평균을 구하시오.
bike[, "month"] = month(bike$datetime)
head(bike, 2)
aggregate(data = bike, casual ~ month, FUN = "mean")
# Q2. 요일별 registered의 평균을 구하시오.
#  ※ 요일은 wday() 함수 사용
bike[, "wday"] = wday(bike$datetime)
aggregate(data = bike, registered ~ wday, FUN = "mean")

df_agg = aggregate(data = bike, casual ~ month, 
                   FUN = "mean")
library("ggplot2")
ggplot(data = df_agg,
       aes(x = month,
           y = casual,
           fill = casual)) + 
  geom_col() + 
  theme_bw() + 
  theme(legend.position = "none")

