install.packages("binman")
library("RSelenium")
drv_version = binman::list_versions("chromedriver")[[1]]
drv = rsDriver(port = sample(3000L:5000L, size = 1), browser = "chrome", 
               chromever = drv_version[length(drv_version) - 1])
cl = drv$client

cl$navigate("https://www.gmarket.co.kr")
# Headless : 브라우저 창을 별도로 띄우지 않는 것

cl$close()


eCaps = list(chromeOptions = list(args = c('--headless', 
                                           '--disable-gpu', 
                                           '--window-size=1280,800')))
drv = rsDriver(port = sample(3000L:5000L, size = 1), browser = "chrome", 
               chromever = drv_version[length(drv_version) - 1],
               extraCapabilities = eCaps)
cl = drv$client
cl$navigate("https://www.gmarket.co.kr")
source = cl$getPageSource()
library("rvest")
text = read_html(source[[1]], encoding = "UTF-8")
text