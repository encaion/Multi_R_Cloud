library("rvest")

text = "asdf1234"

as.numeric(substr(text, start = 5, stop = 8)) + 1000

text %>% 
  substr(start = 5, stop = 8) %>%  
  as.numeric() %>% 
  .[] + 1000

text %>% 
  substr(start = 5, stop = 8) %>%  
  as.numeric() %>% 
  `+`(1000)

url = "https://search.naver.com/search.naver?where=news&sm=tab_jum&query=%ED%81%AC%EB%A1%A4%EB%A7%81"

text = read_html(url, encoding = "UTF-8")
text

# //*[@id="main_pack"]/section[1]/div/div[3]/ul

text %>% 
  html_nodes(xpath = '//*[@id="main_pack"]/section[1]/div/div[3]/ul')

text %>% 
  html_nodes(xpath = '//*[@id="main_pack"]//*/ul[@class="list_news"]')
# //* <-- 앞에 어떤 것이 있던 관계 없이.

text %>% 
  html_nodes(xpath = '/html/body/div[3]/div[2]/div/div[1]/section[1]/div/div[3]/ul')

text %>% 
  html_nodes(xpath = '//*[@id="main_pack"]//*/ul[@class="list_news"]') -> list_news

list_news %>%  
  html_nodes(xpath = "//*/div[@class='news_area']/a") %>% 
  html_text()

list_news %>%  
  html_nodes(xpath = "//*/div[@class='news_area']/a") %>% 
  html_attr(name = "href")

# Q. 뉴스기사 제공처(언론사명), 기사 제목, 기사 링크를 수집하여
#    df_news 객체에 데이터프레임으로 저장하시오.
text %>% 
  html_nodes(xpath = '//*[@id="main_pack"]//*/ul[@class="list_news"]') -> list_news

list_news %>%  
  html_nodes(xpath = "//*/div[@class='news_area']/a") %>% 
  html_text() -> news_title

list_news %>%  
  html_nodes(xpath = "//*/div[@class='news_area']/a") %>% 
  html_attr(name = "href") -> news_link

list_news %>%  
  html_nodes(xpath = "//div[@class='info_group']/a[@class='info press']/text()") %>%  
  html_text() -> news_press

# text() 는 바로 아래의 텍스트만 추출하는 xpath 문법

df_news = data.frame(press = news_press,
                     title = news_title,
                     link  = news_link)
head(df_news, 2)

Sys.Date()
Sys.time()

# [[:punct:]] <- 대부분의 특수문자
sys_time = gsub(pattern = "[[:punct:]]", replacement = "", Sys.time())
sys_time = gsub(pattern = " ", replacement = "_", sys_time)
sys_time

file_name = paste0("naver_news_keyword_", sys_time, ".csv")
file_name


# https://search.naver.com/search.naver?
# &where=news
# &query=%ED%81%AC%EB%A1%A4%EB%A7%81
# &sm=tab_pge
# &sort=0
# &photo=0
# &field=0
# &reporter_article=
# &pd=0&ds=&de=&docid=
# &nso=so:r,p:all,a:all
# &mynews=0
# &cluster_rank=14
# &start=11
# &refresh_start=0

url_base = "https://search.naver.com/search.naver?&where=news&query="
keyword = "%ED%81%AC%EB%A1%A4%EB%A7%81"
url_queries = "&sm=tab_pge&sort=0&photo=0&field=0&reporter_article=&pd=0&ds=&de=&docid=&nso=so:r,p:all,a:all&mynews=0&cluster_rank=14&start="
article_start = 1
url_etc = "&refresh_start=0"

url = paste0(url_base, keyword, url_queries, article_start, url_etc)
url

seq(from = 1, to = 31, by = 10)
iconv(URLdecode(keyword), from = "UTF-8", to = "CP949")
URLencode(iconv("크롤링", from = "CP949", to = "UTF-8"))

#### ___ 최종? 네이버 뉴스 크롤러 ####
keywords = c("코로나", "크롤링")
list_article_start = seq(from = 1, to = 31, by = 10)

url_base = "https://search.naver.com/search.naver?&where=news&query="
url_queries = "&sm=tab_pge&sort=0&photo=0&field=0&reporter_article=&pd=0&ds=&de=&docid=&nso=so:r,p:all,a:all&mynews=0&cluster_rank=14&start="
url_etc = "&refresh_start=0"

df_news = data.frame()
for(n_keyword in keywords){
  print(n_keyword)
  for(article_start in list_article_start){
    print(article_start)
    url = paste0(url_base, 
                 URLencode(iconv(n_keyword, from = "CP949", to = "UTF-8")),
                 url_queries, article_start, url_etc)
    
    # 소스코드 수집
    text = read_html(url, encoding = "UTF-8")
    
    # 데이터 정제
    text %>% 
      html_nodes(xpath = '//*[@id="main_pack"]//*/ul[@class="list_news"]') -> list_news
    
    list_news %>%  
      html_nodes(xpath = "//*/div[@class='news_area']/a") %>% 
      html_text() -> news_title
    
    list_news %>%  
      html_nodes(xpath = "//*/div[@class='news_area']/a") %>% 
      html_attr(name = "href") -> news_link
    
    list_news %>%  
      html_nodes(xpath = "//div[@class='info_group']/a[@class='info press']/text()") %>%  
      html_text() -> news_press
    
    # 데이터 병합
    df_news_sub = data.frame(press = news_press,
                             title = news_title,
                             link  = news_link)
    df_news = rbind(df_news, df_news_sub)
    
    Sys.sleep(runif(1) * 3) # 균등분포를 따르는 임의의 숫자 1개 활용
  }
  # write.csv()
}
nrow(df_news)
df_news$title
head(df_news, 2)

#### 다음 주식 ####
url = "https://finance.daum.net/domestic"
text = read_html(url, encoding = "UTF-8")

text %>% 
  html_nodes(xpath = '//div[@id="boxDashboard"]') %>%  
  html_children()

#### example for windows(local) ####
library("RSelenium")
drv_version = binman::list_versions("chromedriver")[[1]]
drv = rsDriver(port = sample(3000L:5000L, size = 1), browser = "chrome", 
               chromever = drv_version[length(drv_version) - 1])
cl = drv$client

cl$navigate("https://finance.daum.net/domestic")
text = cl$getPageSource()[[1]]
# writeLines(text, "daum_stock_sample_20201113_120900.txt")
text = readLines("daum_stock_sample_20201113_120900.txt")
text = read_html(paste0(text, collapse = ""))
text

text %>% 
  html_nodes(xpath = '//div[@id="boxDashboard"]') %>% 
  html_nodes(xpath = 'ul') %>%  
  html_children() -> dash_index

dash_index %>% 
  html_children() %>%  
  html_text() %>%  
  gsub(pattern = "^ {1,}| {1,}$", replacement = "") %>% 
  gsub(pattern = " {2,}", replacement = "@") %>%  
  strsplit(split = "@") -> dash_index_values

unlist(dash_index_values)
matrix(unlist(dash_index_values), nrow = 3, byrow = TRUE)

dash_index_values %>%  
  unlist() %>%  
  matrix(nrow = 3, byrow = TRUE) %>% 
  as.data.frame() -> df_dash_index
colnames(df_dash_index) = c("index", "value", "diff", "diff_per")
df_dash_index


text %>% 
  html_nodes(xpath = '//div[@id="boxDashboard"]') %>%  
  html_nodes(xpath = '//div[@class="txtB"]/dl[2]') -> inv_trend
inv_trend %>% 
  html_nodes(xpath = 'dd/a/text()') -> inv_trend_type

inv_trend %>% 
  html_nodes(xpath = 'dd/a/p/text()') -> inv_trend_value

df_inv_trend = data.frame(index = rep(c("KOSPI", "KOSDAQ", "KOSPI200"), each = 4),
                          type = as.character(inv_trend_type),
                          value = as.character(inv_trend_value))
df_inv_trend

# Q. value 변수의 +와 ,를 제거하고 해당 변수를 수치형 변수로 바꾸시오.
df_inv_trend[, "value"] = as.numeric(gsub("+|,", "", df_inv_trend$value))
class(df_inv_trend$value)
df_inv_trend

#### word cloud ####
df = read.csv("naver_news_keyword_cloud_201113.csv")
head(df, 2)
# Q1. 제목에서 한글, 영어, 숫자, 띄어쓰기를 제외한 나머지를
#    한 칸 띄어쓰기로 치환하시오.
df[, "title"] = gsub(pattern = "[^ㄱ-힣a-zA-Z0-9 ]", 
                     replacement = " ", 
                     x = df$title)
head(df, 2)

# Q2. 두 칸 이상 띄어쓰기를 한칸으로 수정하시오. 
#     그리고 제목의 앞과 뒤에 띄어쓰기가 있다면 제거하시오.
df[, "title"] = gsub(pattern = " {2,}", replacement = " ", df$title)
df[, "title"] = gsub(pattern = "^ | $", replacement = "", df$title)
df$title

# Q3. 숫자로만 이루어진 단어를 제거하시오.
df[, "title"] = gsub(pattern = " [0-9]{1,} | [0-9 ]{3,} ", 
                     replacement = " ", df$title)
df$title
# 1: 1개 이상의 연속된 숫자 양 옆에 띄어쓰기가 있는 경우 띄어쓰기로 치환
# 2: 3개 이상의 연속된 숫자 또는 띄어쓰기 양 옆에 띄어쓰기가 있는 경우 띄어쓰기로 치환

# 불필요 텍스트 제거 -> 띄어쓰기 교정 -> 형태소 분석(명사, 조사 등 각종 정보 매핑)

df$title %>% 
  strsplit(split = " ") %>% 
  unlist() %>% 
  table() %>%  
  as.data.frame() -> df_wcnt
colnames(df_wcnt) = c("word", "count")
head(df_wcnt)

df_wcnt_sub = df_wcnt[df_wcnt$count > 1, ]
df_wcnt_sub = df_wcnt_sub[order(df_wcnt_sub$count, decreasing = TRUE), ]
rownames(df_wcnt_sub) = NULL
head(df_wcnt_sub)

# install.packages("ggwordcloud")
library("ggwordcloud")
ggplot(data = df_wcnt_sub,
       aes(label = word, 
           size  = count)) + 
  geom_text_wordcloud() + 
  scale_size_area(max_size = 20) + 
  theme_void()

set.seed(123)
df_wcnt_sub[, "color"] = sample(letters[1:4], 
                                size = nrow(df_wcnt_sub),
                                replace = TRUE)
ggplot(data = df_wcnt_sub,
       aes(label = word, 
           size  = count,
           color = color)) + 
  geom_text_wordcloud() + 
  scale_size_area(max_size = 20) + 
  theme_void()

# install.packages("wordcloud2")
library("wordcloud2")
df_wcnt_sub[, "count2"] = df_wcnt_sub$count * 1.5
wordcloud2(data = df_wcnt_sub[, c("word", "count2")])


ggplot(data = df_wcnt_sub,
       aes(x = word,
           y = count)) + 
  geom_col()

head(df_wcnt_sub)
df_wcnt_top30 = df_wcnt_sub[1:30, ]
ggplot(data = df_wcnt_top30,
       aes(x = word,
           y = count,
           fill = count)) + 
  geom_col()

ggplot(data = df_wcnt_top30,
       aes(x = word,
           y = count,
           fill = count)) + 
  geom_col() + 
  theme_bw() + 
  theme(legend.position = "none")

ggplot(data = df_wcnt_top30,
       aes(x = word,
           y = count,
           fill = count)) + 
  geom_col() + 
  coord_flip() + 
  theme_bw() + 
  theme(legend.position = "none")


ggplot(data = df_wcnt_top30,
       aes(x = reorder(word, count), # 또는 -count
           y = count,
           fill = count)) + 
  geom_col() + 
  coord_flip() + 
  theme_bw() + 
  theme(legend.position = "none")

ggplot(data = df_wcnt_top30,
       aes(x = reorder(word, count), # 또는 -count
           y = count,
           fill = count)) + 
  geom_col() + 
  scale_y_continuous(expand = c(0.01, 0.01)) +
  coord_flip() +
  theme_bw() + 
  theme(legend.position = "none")


ggplot(data = df_wcnt_top30,
       aes(x = reorder(word, count), # 또는 -count
           y = count,
           fill = count)) + 
  geom_col() + 
  scale_y_continuous(expand = c(0.01, 0.01),
                     limits = c(0, max(df_wcnt_top30$count) * 1.05)) +
  coord_flip() +
  theme_bw() + 
  theme(legend.position = "none")

ggplot(data = df_wcnt_top30,
       aes(x = reorder(word, count), # 또는 -count
           y = count,
           fill = count)) + 
  geom_col() + 
  scale_y_continuous(expand = c(0.01, 0.01),
                     limits = c(0, max(df_wcnt_top30$count) * 1.05)) +
  coord_flip() +
  labs(x = NULL, y = "Count") + 
  theme_bw() + 
  theme(legend.position = "none",
        panel.grid.major.x = element_line(size = 3,
                                          color = "#DDDDDD"))

ggplot(data = df_wcnt_top30,
       aes(x = reorder(word, count), # 또는 -count
           y = count,
           fill = count)) + 
  geom_col() + 
  scale_y_log10(expand = c(0.01, 0.01)) +
  coord_flip() +
  labs(x = NULL, y = "Count") + 
  theme_bw() + 
  theme(legend.position = "none",
        panel.grid.major.x = element_line(size = 3,
                                          color = "#DDDDDD"))

#### excel.link ####
library("excel.link")
xlrc[["a1"]] = 1:10
xl.sheet.add("new")

for(n in 1:10){
  xlrc[[paste0(letters[n], n)]] = n
  print(paste0(letters[n], n))
}

xl.sheet.name()
xl.sheet.activate("Sheet1") # 활성화 하고자 하는 시트
xl.sheets() # 현재 사용중인 workbook의 시트명 출력

qplot(1:10, 1:10, size = 3)
xlrc[["b3"]] = current.graphics()

xl.sheet.add("iris")
xlrc[["a1"]] = iris

model = lm(Petal.Length ~ Petal.Width, data = iris)
model_summary = summary(model)
model_summary

xl.sheet.add("model_iris")
xlrc[["a1"]] = model_summary$coefficients
