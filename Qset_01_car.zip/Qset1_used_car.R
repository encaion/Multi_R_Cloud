# "Qset1_used_car_price.csv" 파일을 읽어와서 
# df객체에 저장하고 다음 문제에 답하시오.
df = read.csv("Qset1_used_car_price.csv",
              stringsAsFactors = FALSE)
head(df)

# 데이터 설명은 다음 링크 참고.
# https://www.coursehero.com/file/23683603/toyotacorolla/

#### Q1 ####
# row 개수와 column 개수를 확인하시오.

#### Q2 ####
# 속성이 문자인 변수는 몇 개 인가?

#### Q3 ####
# 가장 비싼 차량의 가격은 얼마인가?

#### Q4 ####
# 차량 문 개수에 따른 가격 평균을 확인하시오.

#### Q5 ####
# 가장 저렴한 차량의 에어백 개수를 확인하시오.

#### Q6 ####
# Automatic 이면서 ABS가 있는 차량의 평균 가격은 얼마인가? 
